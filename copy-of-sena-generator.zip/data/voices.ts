
import type { Voice, VoiceGender, VoiceStyle } from '../types';

export const GENDERS: readonly VoiceGender[] = ['Pria', 'Wanita', 'Netral'];
export const STYLES: readonly VoiceStyle[] = ['Narator', 'Pendidik/Pengajar', 'Meyakinkan/Profesional', 'Pelatih/Ceria', 'Motivator', 'Ekspresif secara Emosional'];

export const VOICES: Voice[] = [
  {
    name: 'Kore',
    apiName: 'Kore',
    description: 'Tegas, Jelas',
    gender: 'Wanita',
    styles: ['Narator', 'Pendidik/Pengajar', 'Meyakinkan/Profesional'],
  },
  {
    name: 'Puck',
    apiName: 'Puck',
    description: 'Ceria, Hangat',
    gender: 'Pria',
    styles: ['Pelatih/Ceria', 'Motivator', 'Narator'],
  },
  {
    name: 'Charon',
    apiName: 'Charon',
    description: 'Dalam, Berwibawa',
    gender: 'Pria',
    styles: ['Narator', 'Meyakinkan/Profesional'],
  },
  {
    name: 'Zephyr',
    apiName: 'Zephyr',
    description: 'Lembut, Ramah',
    gender: 'Wanita',
    styles: ['Pelatih/Ceria', 'Narator', 'Ekspresif secara Emosional'],
  },
  {
    name: 'Fenrir',
    apiName: 'Fenrir',
    description: 'Serak, Kuat',
    gender: 'Pria',
    styles: ['Motivator', 'Meyakinkan/Profesional'],
  },
  // Adding fictional voices to better match the screenshot example
  {
    name: 'Achernar',
    apiName: 'Zephyr', // Using Zephyr as the base for a soft female voice
    description: 'Lembut, Halus',
    gender: 'Wanita',
    styles: ['Narator', 'Ekspresif secara Emosional'],
  },
  {
    name: 'Sirius',
    apiName: 'Charon', // Using Charon for a professional male voice
    description: 'Profesional, Tenang',
    gender: 'Pria',
    styles: ['Meyakinkan/Profesional', 'Pendidik/Pengajar'],
  },
];