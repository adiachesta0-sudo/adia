import { GoogleGenAI, GenerateContentResponse, Modality, Type } from "@google/genai";
import type { GeneratedContentPack } from '../types';


let ai: GoogleGenAI | null = null;

function getGoogleAI() {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }
  // Create a new instance every time to ensure the latest API key is used, especially for Veo.
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai;
}

const fileToGenerativePart = async (file: File) => {
    const base64EncodedData = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
    });
    return {
        inlineData: {
            data: base64EncodedData,
            mimeType: file.type,
        },
    };
};

const base64ToFile = (dataUrl: string, filename: string): File => {
    const [header, data] = dataUrl.split(',');
    const mime = header.match(/:(.*?);/)?.[1] || 'image/png';
    const bstr = atob(data);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
};


export const generateText = async (prompt: string, systemInstruction?: string, model: string = 'gemini-3-flash-preview'): Promise<string> => {
  const ai = getGoogleAI();
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction,
      },
    });
    return response.text ?? '';
  } catch (error) {
    console.error("Gemini API text generation error:", error);
    throw new Error("Gagal membuat teks. Silakan periksa kunci API dan koneksi jaringan Anda.");
  }
};

export const generateImage = async (prompt: string, model: string = 'gemini-2.5-flash-image', aspectRatio?: string): Promise<string> => {
  const ai = getGoogleAI();
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model,
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        ...(aspectRatio && { imageConfig: { aspectRatio } }),
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("Tidak ada data gambar yang ditemukan dalam respons.");

  } catch (error) {
    console.error("Gemini API image generation error:", error);
    throw new Error("Gagal membuat gambar. Prompt mungkin telah diblokir atau terjadi kesalahan.");
  }
};

export const generateProductImage = async (
    prompt: string,
    productImage: File,
    aspectRatio: string,
    modelImage?: File,
    supportingImage?: File,
    backgroundImage?: File,
    signal?: AbortSignal
): Promise<string> => {
    if (signal?.aborted) {
        throw new DOMException('Proses dibatalkan oleh pengguna', 'AbortError');
    }

    const ai = getGoogleAI();
    const contents: { parts: any[] } = { parts: [] };

    // Add product image
    const productPart = await fileToGenerativePart(productImage);
    contents.parts.push(productPart);

    // Add supporting image if it exists
    if (supportingImage) {
        const supportingPart = await fileToGenerativePart(supportingImage);
        contents.parts.push(supportingPart);
    }
    
    // Add background image if it exists
    if (backgroundImage) {
        const backgroundPart = await fileToGenerativePart(backgroundImage);
        contents.parts.push(backgroundPart);
    }

    // Add model image if it exists
    if (modelImage) {
        const modelPart = await fileToGenerativePart(modelImage);
        contents.parts.push(modelPart);
    }

    // Add the text prompt
    contents.parts.push({ text: prompt });

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents,
            config: {
                imageConfig: {
                    aspectRatio,
                },
            },
        });
        
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
        throw new Error("Tidak ada data gambar yang ditemukan dalam respons.");

    } catch (error) {
        console.error("Gemini API product image generation error:", error);
        throw new Error("Gagal membuat gambar. Prompt mungkin telah diblokir atau terjadi kesalahan.");
    }
};


export const generateTextToSpeech = async (text: string, voiceName: string): Promise<string> => {
    const ai = getGoogleAI();
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voiceName },
                    },
                },
            },
        });
        // FIX: Audio data is returned in `inlineData.data`, not `image.imageBytes`.
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("Tidak ada data audio yang diterima dari API.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Gemini API TTS error:", error);
        throw new Error("Gagal membuat audio. Silakan periksa prompt dan kunci API Anda.");
    }
};

export const generateCharacterDNA = async (characterImage: File): Promise<string> => {
    const ai = getGoogleAI();
    const imagePart = await fileToGenerativePart(characterImage);
    const prompt = `Analisis orang dalam gambar ini secara mendetail. Deskripsikan fitur visual utamanya dalam daftar kata kunci yang dipisahkan koma. Ini akan digunakan sebagai 'DNA visual' untuk menjaga konsistensi karakter.
KRUSIAL: Fokus HANYA pada fitur fisik yang permanen dan tidak berubah.
TERMASUK: bentuk wajah, warna mata, gaya rambut (potongan dan warna), warna kulit, perkiraan etnis, dan fitur wajah yang menonjol (misalnya: tahi lalat, lesung pipi).
JANGAN TERMASUK: Pakaian, pose, ekspresi wajah, atau pencahayaan, karena ini akan berubah di setiap gambar.
Contoh output: wajah oval, mata cokelat tua, rambut hitam lurus sebahu, kulit sawo matang khas Indonesia, alis tebal.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: { parts: [imagePart, { text: prompt }] },
        });
        return response.text ?? 'Tidak dapat menganalisis DNA karakter.';
    } catch (error) {
        console.error("Gemini API character DNA generation error:", error);
        throw new Error("Gagal menganalisis gambar karakter.");
    }
};

export const generateVideoScene = async (
    prompt: string, 
    image: File, 
    aspectRatio: '16:9' | '9:16',
    onProgress: (message: string) => void
): Promise<string> => {
    onProgress("Memulai pembuatan video...");
    const ai = getGoogleAI();
    const imagePart = await fileToGenerativePart(image);
    const imageBytes = imagePart.inlineData.data;

    try {
        let operation = await ai.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt,
            image: { imageBytes, mimeType: image.type },
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: aspectRatio
            }
        });
        
        onProgress("Pemrosesan video telah dimulai. Ini mungkin memakan waktu beberapa menit...");

        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 10000));
            onProgress("Memeriksa status video...");
            operation = await ai.operations.getVideosOperation({ operation: operation });
        }
        
        onProgress("Menyelesaikan video...");
        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) throw new Error("Pembuatan video gagal atau tidak mengembalikan tautan.");
        
        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        if (!videoResponse.ok) {
            throw new Error(`Gagal mengunduh video. Status: ${videoResponse.statusText}`);
        }
        const videoBlob = await videoResponse.blob();
        return URL.createObjectURL(videoBlob);

    } catch(error: any) {
        console.error("Gemini API video generation error:", error);
        if (error.message.includes("Requested entity was not found")) {
            throw new Error("Pembuatan video gagal. Silakan periksa kunci API Anda dan pastikan itu dari proyek GCP berbayar yang valid. Anda mungkin perlu memilih kunci baru.");
        }
        throw new Error("Gagal membuat video. Silakan coba lagi.");
    }
};

export const generateStoryScriptFromImage = async (image: File, language: string): Promise<string> => {
    const ai = getGoogleAI();
    const imagePart = await fileToGenerativePart(image);
    const prompt = `Anda adalah penulis naskah ahli untuk iklan video pendek (seperti TikTok atau Instagram Reels).
    Analisis produk dalam gambar yang disediakan dan buat skrip iklan video 4 adegan dalam bahasa ${language}.
    Ikuti struktur ini dengan ketat: Hook, Problem, Solution, dan Call to Action (CTA).
    Untuk setiap adegan, sediakan [SKRIP] untuk sulih suara dan [PROMPT VISUAL] yang detail untuk AI teks-ke-video atau teks-ke-gambar.
    Gunakan 'SCENE X - [JUDUL]' sebagai pemisah untuk setiap adegan.

    PENTING:
    - KRUSIAL: Latar belakang, lingkungan, produk utama, dan penampilan karakter (wajah, rambut, dll.) dalam SEMUA [PROMPT VISUAL] harus konsisten dan didasarkan pada gambar referensi yang diberikan. Jangan mengubah elemen-elemen inti ini.
    - Fokus [PROMPT VISUAL] adalah untuk mendeskripsikan perubahan pada AKSI, EKSPRESI KARAKTER, atau GERAKAN KAMERA di dalam lingkungan yang sudah ditetapkan tersebut.
    - Pastikan ada alur cerita yang jelas dan konsisten dari satu adegan ke adegan berikutnya. Narasi harus mengalir secara logis dari Hook ke CTA.
    - [PROMPT VISUAL] harus sinematik. Deskripsikan gerakan kamera (misalnya, 'dolly zoom', 'pan lambat'), ekspresi, pencahayaan, dan suasana keseluruhan.
    - Seluruh skrip harus relevan dengan produk yang ditampilkan dalam gambar.

    Contoh untuk satu adegan:
    SCENE 1 - HOOK
    [SKRIP] Apakah Anda lelah dengan...?
    [PROMPT VISUAL] Bidikan close-up ekstrem pada karakter yang terlihat lelah dan frustrasi di mejanya, kamera perlahan-lahan mundur menunjukkan tumpukan kertas yang berantakan, pencahayaan kantor yang suram.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: { parts: [imagePart, { text: prompt }] },
        });
        return response.text ?? 'Tidak dapat membuat skrip cerita dari gambar.';
    } catch (error) {
        console.error("Gemini API story script from image generation error:", error);
        throw new Error("Gagal membuat skrip cerita dari gambar.");
    }
};

interface AffiliateContentInputs {
    mainProductPhoto: File;
    supportingPhoto?: File;
    modelPhoto?: File;
    backgroundImage?: File;
    description: string;
    modelClothing: string;
    modelPose: string;
    ratio: string;
    language: string;
    storeName: string;
    accent: string;
}

export const generateAffiliateContent = async (
    inputs: AffiliateContentInputs,
    onBatchComplete: (batchResults: { theme: string, imageUrl: string }[]) => void,
    onDnaComplete: (dna: string) => void,
    onProgress: (message: string) => void
): Promise<void> => {
    const { mainProductPhoto, supportingPhoto, modelPhoto, backgroundImage, description, modelClothing, modelPose, ratio, language, storeName, accent } = inputs;
    
    let visualDNA = '';
    if (modelPhoto) {
        try {
            onProgress('Memindai DNA Visual model...');
            visualDNA = await generateCharacterDNA(modelPhoto);
            onDnaComplete(visualDNA);
        } catch (e) {
            console.error("Tidak dapat membuat DNA visual untuk model.", e);
            onProgress('Gagal memindai DNA. Melanjutkan tanpa DNA.');
        }
    }

    const POSES_PER_THEME = [
        "Pose percaya diri dan ceria, tertawa sambil melihat sedikit menjauh dari kamera.",
        "Pose aksi dinamis, seolah-olah ditangkap di tengah gerakan saat berinteraksi secara alami dengan produk.",
        "Pose gaya hidup kasual dan santai, bersandar di suatu permukaan atau duduk dengan nyaman.",
        "Fokus close-up pada interaksi model dengan produk, menunjukkan detail dan tekstur.",
    ];

    const THEMES = [
        { name: "Gaya Hidup di Kafe", style: "Gaya hidup di kafe yang nyaman dengan nada hangat, cahaya lembut, dan fokus pada suasana santai." },
        { name: "Luar Ruangan saat Senja", style: "Di luar ruangan saat golden hour, dengan suasana dreamy yang dibanjiri cahaya matahari." },
        { name: "Kota Malam Hari", style: "Suasana kota yang edgy dan bersemangat di malam hari, dengan lampu neon dan pantulan cahaya." },
        { name: "Minimalis Modern", style: "Minimalis dan modern, menggunakan elemen arsitektur dan bayangan tegas." },
        { name: "Studio Profesional", style: "Iklan komersial yang dipoles, pencahayaan profesional high-end, latar belakang studio yang bersih." },
        { name: "Gaya UGC Otentik", style: "Gaya UGC (User-Generated Content), otentik, seolah diambil dengan smartphone, pencahayaan alami." },
        { name: "Sinematik B-Roll", style: "Gaya sinematik B-roll, atmosferik, fokus pada detail dan tekstur produk, seringkali dengan bokeh yang indah." },
        { name: "E-commerce di Latar Netral", style: "Gaya model e-commerce, bidikan seluruh tubuh dengan latar belakang abu-abu muda netral, pencahayaan terang dan jelas." },
        { name: "Interior Mewah", style: "Interior mewah seperti lobi hotel modern atau apartemen kelas atas, suasana elegan." },
        { name: "Petualangan Alam", style: "Latar belakang alam liar seperti hutan lebat atau pegunungan, menunjukkan produk dalam konteks petualangan." },
        { name: "Suasana Pantai Tropis", style: "Suasana pantai yang cerah dengan pasir putih, air biru jernih, dan pohon kelapa." },
        { name: "Gaya Retro/Vintage", style: "Gaya retro dengan palet warna pudar, properti vintage, dan nuansa nostalgia." },
        { name: "Futuristik & Teknologi", style: "Latar futuristik dengan garis-garis bersih, permukaan metalik, dan pencahayaan bernuansa dingin." },
        { name: "Olahraga & Kebugaran", style: "Di gym atau lapangan olahraga, menunjukkan produk dalam konteks aktif dan energik." },
        { name: "Seni Abstrak", style: "Latar belakang artistik abstrak dengan warna-warna komplementer yang berani dan bentuk geometris." },
        { name: "Pedesaan yang Tenang", style: "Suasana pedesaan yang damai, mungkin di dekat lumbung atau di ladang bunga." },
        { name: "Gaya Jalanan Perkotaan", style: "Gaya street style di lingkungan perkotaan yang ramai dengan grafiti dan arsitektur kota." },
        { name: "Kenyamanan di Rumah", style: "Suasana nyaman di dalam rumah, mungkin di dekat perapian atau di sofa yang nyaman." },
        { name: "Pesta & Perayaan", style: "Suasana pesta yang meriah dengan konfeti, lampu berkelip, dan ekspresi gembira." },
        { name: "Misterius & Dramatis", style: "Pencahayaan dramatis dengan bayangan pekat, menciptakan suasana misterius dan intens." },
    ];
    
    const TOTAL_IMAGES = 80;
    const allPrompts: { theme: string, prompt: string }[] = [];

    for (let i = 0; i < TOTAL_IMAGES; i++) {
        const themeIndex = Math.floor(i / POSES_PER_THEME.length);
        const poseIndex = i % POSES_PER_THEME.length;
        
        const currentTheme = THEMES[themeIndex];
        const currentPose = modelPose.trim() ? `${modelPose} (variasi ${poseIndex + 1})` : POSES_PER_THEME[poseIndex];
        const currentStyle = backgroundImage ? 'Sesuai dengan latar belakang yang diberikan pengguna' : currentTheme.style;

        const fullPrompt = `
            ABSOLUTELY CRITICAL: Buat sebuah foto komersial yang hiper-realistis, kualitas 8k.
            **Fokus utama dan pahlawan dalam foto ini adalah produk:** ${description}.
            **ATURAN PALING KRUSIAL: Produk yang ditampilkan dalam gambar referensi HARUS digunakan PERSIS SEPERTI ADANYA. JANGAN PERNAH mengubah desain, warna, merek, atau detail apa pun. Tugas AI adalah mengintegrasikan produk yang sama persis dari gambar ke dalam adegan baru, BUKAN menata ulang produk itu sendiri.**
            Seorang model hadir untuk melengkapi produk, mengenakan: ${modelClothing}.
            ${visualDNA ? `**SANGAT PENTING:** Fitur wajah model HARUS secara ketat mematuhi deskripsi ini (DNA visual): ${visualDNA}. Sangat penting bahwa model terlihat seperti orang yang sama dari foto referensi yang diberikan.` : ''}
            Gaya dan Suasana: ${currentStyle}.
            Pose Model: "${currentPose}".
            Aksen/Suasana yang diinginkan: ${accent}.
            ${backgroundImage ? '**KRUSIAL:** Tempatkan model dan produk secara alami ke dalam gambar latar belakang yang disediakan. Pencahayaan, bayangan, dan gradasi warna pada model dan produk HARUS sangat cocok dengan latar belakang untuk menciptakan komposit yang mulus dan realistis.' : ''}
            Gaya Fotografi: Format foto RAW. Diambil dengan DSLR profesional (seperti Sony A7 IV) dengan lensa 85mm f/1.4 yang tajam, menciptakan depth of field yang sangat dangkal dan bokeh yang indah. Pencahayaan sinematik dan lembut, dibuat dengan cermat untuk menciptakan sorotan dan bayangan realistis. Tekankan tekstur hiper-realistis: pori-pori kulit alami, tenunan halus kain, dan permukaan material yang presisi.
            Instruksi Kritis: Hasil akhir HARUS sama sekali tidak bisa dibedakan dari foto asli beranggaran tinggi. Sama sekali TIDAK boleh ada "tampilan AI", kulit seperti plastik, atau fitur yang terlalu halus. Pastikan anatomi manusia realistis.
            Nama toko untuk papan nama (jika berlaku) adalah ${storeName}. Teks apa pun harus dalam bahasa ${language}.
        `;
        allPrompts.push({ theme: currentTheme.name, prompt: fullPrompt });
    }

    const BATCH_SIZE = 8;
    for (let i = 0; i < allPrompts.length; i += BATCH_SIZE) {
        const batch = allPrompts.slice(i, i + BATCH_SIZE);
        onProgress(`Memproses batch ${i/BATCH_SIZE + 1}/${allPrompts.length/BATCH_SIZE}... (${i + batch.length}/${TOTAL_IMAGES} foto)`);

        try {
            const imagePromises = batch.map(p => 
                generateProductImage(
                    p.prompt,
                    mainProductPhoto,
                    ratio,
                    modelPhoto,
                    supportingPhoto,
                    backgroundImage
                ).then(imageUrl => ({ theme: p.theme, imageUrl }))
            );

            const batchResults = await Promise.all(imagePromises);
            onBatchComplete(batchResults);
        } catch (error) {
            console.error(`Gagal memproses batch ${i/BATCH_SIZE + 1}:`, error);
            throw new Error(`Gagal pada batch ${i/BATCH_SIZE + 1}. Silakan periksa prompt atau coba lagi.`);
        }
    }
};

export const generateVideoPrompt = async (productInteraction: string, modelGender: string): Promise<string> => {
    const ai = getGoogleAI();
    const metaPrompt = `
    Anda adalah seorang direktur kreatif untuk iklan video pendek (seperti video TikTok atau Instagram Reel).
    Berdasarkan konsep foto produk berikut, buatlah sebuah prompt visual yang ringkas dan sinematik dalam Bahasa Indonesia untuk AI generator video (seperti Veo).

    Deskripsi Produk/Adegan: "${productInteraction}"
    Model: Seorang model ${modelGender}.

    Prompt video harus terasa seperti iklan pendek yang menarik.
    1. Deskripsikan adegan pendek dan dinamis (3-5 detik).
    2. Fokus pada aksi, gerakan kamera yang spesifik (misal: 'orbit shot', 'push-in lambat'), dan daya tarik visual.
    3. Tekankan interaksi antara model dan produk, dan bagaimana interaksi tersebut menunjukkan manfaat atau daya tarik produk.
    4. Prompt HARUS dalam Bahasa Indonesia dan dalam satu paragraf.

    Contoh output: "Sebuah bidikan orbit lambat mengelilingi seorang model wanita yang tersenyum puas saat mengaplikasikan produk perawatan kulit, kamera kemudian melakukan push-in untuk fokus pada tekstur produk yang berkilau di kulitnya, dengan cahaya pagi yang lembut masuk dari jendela."

    Hasilkan prompt sekarang.
    `;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: metaPrompt,
        });
        return response.text ?? 'Tidak dapat membuat prompt video.';
    } catch (error) {
        console.error("Gemini API video prompt generation error:", error);
        throw new Error("Gagal membuat prompt video.");
    }
};

export const generateVideoPromptFromText = async (imagePrompt: string): Promise<string> => {
    const ai = getGoogleAI();
    const metaPrompt = `
    Anda adalah seorang direktur kreatif ahli. Tugas Anda adalah mengubah deskripsi gambar statis menjadi prompt video yang dinamis.
    Prompt video harus sinematik dan cocok untuk platform seperti TikTok atau Instagram Reels.

    Deskripsi Gambar Asli: "${imagePrompt}"

    Instruksi:
    1. Pikirkan tentang apa yang terjadi sesaat before, selama, dan sesaat setelah momen di gambar itu. Bagaimana gambar ini bisa hidup?
    2. Tulis prompt video dalam satu paragraf yang deskriptif.
    3. Gunakan kata kerja yang kuat dan deskripsi sensorik.
    4. Deskripsikan aksi, emosi, dan gerakan kamera yang spesifik (misalnya: 'gerak lambat', 'kamera mengorbit dari bawah ke atas', 'zoom cepat').
    5. Prompt video HARUS dalam Bahasa Indonesia.

    Contoh:
    - Deskripsi Gambar Asli: "Seekor singa megah di hutan bersalju, sangat realistis, 8k"
    - Contoh Output Prompt Video: "Dalam gerak lambat sinematik, seekor singa megah berjalan melewati hutan bersalju yang lebat, uap napasnya terlihat di udara dingin. Kamera mengikuti dari samping pada tingkat rendah, menangkap detail bulu dan salju yang berjatuhan dengan lembut di sekitarnya saat ia mengangkat kepalanya untuk mengaum tanpa suara."

    Hasilkan prompt video sekarang.
    `;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: metaPrompt,
        });
        return response.text ?? 'Tidak dapat membuat prompt video.';
    } catch (error) {
        console.error("Gemini API video prompt generation error:", error);
        throw new Error("Gagal membuat prompt video.");
    }
};

export const generateStoryScenes = async (idea: string): Promise<string> => {
    const ai = getGoogleAI();
    const prompt = `Anda adalah penulis naskah untuk film animasi. Berdasarkan ide cerita: "${idea}", buatlah sebuah cerita pendek dengan 3-4 adegan awal.
    Untuk setiap adegan, berikan [JUDUL ADEGAN] dan [PROMPT VISUAL] yang sangat detail untuk AI generator gambar.
    Gunakan '---' sebagai pemisah antar adegan.
    
    PENTING: Untuk setiap [PROMPT VISUAL], deskripsikan komposisi, pencahayaan, palet warna, dan emosi karakter secara detail. Pastikan ada perkembangan naratif yang logis dan konsisten dari satu adegan ke adegan berikutnya. Setiap adegan baru harus secara alami mengikuti adegan sebelumnya, menciptakan alur cerita yang mulus dan dapat dipercaya. Prompt harus melukiskan gambaran yang lengkap.
    
    Contoh format untuk satu adegan:
    [JUDUL ADEGAN] Budi Menemukan Peta Harta Karun
    [PROMPT VISUAL] Medium shot Budi, seorang anak laki-laki Indonesia dengan kaos merah, menemukan sebuah peta tua yang bersinar di dalam sebuah buku di perpustakaan yang remang-remang. Cahaya keemasan dari jendela menerangi debu yang beterbangan di udara, menciptakan suasana magis. Ekspresinya terkejut dan penuh rasa ingin tahu, dengan mata melebar. Palet warna hangat dengan bayangan yang dalam.

    Prompt visual HARUS dalam Bahasa Indonesia.`;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });
        return response.text ?? 'Tidak dapat membuat adegan cerita.';
    } catch (error) {
        console.error("Gemini API story scenes generation error:", error);
        throw new Error("Gagal membuat adegan cerita.");
    }
};

export const generateModelPosePrompt = async (description: string, productImage: File): Promise<string> => {
    const ai = getGoogleAI();
    const imagePart = await fileToGenerativePart(productImage);
    const metaPrompt = `Anda adalah seorang pengarah kreatif untuk sebuah sesi foto produk. Berdasarkan gambar produk dan deskripsi berikut, buatlah satu ide pose yang kreatif dan singkat untuk seorang model.

Deskripsi Produk: "${description}"

Instruksi:
1. Pose harus menonjolkan fitur terbaik produk tanpa menutupi merek atau detail penting.
2. Jelaskan bahasa tubuh model untuk mencerminkan citra merek (misalnya: percaya diri, santai, energik).
3. Hanya kembalikan deskripsi posenya saja dalam beberapa kata, tanpa kalimat pembuka atau penutup.

Contoh: "bersandar percaya diri sambil menunjukkan produk ke kamera", "tertawa lepas sambil memegang produk dengan kedua tangan", "pose elegan dengan produk diletakkan di telapak tangan".`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: { parts: [imagePart, { text: metaPrompt }] },
        });
        return response.text?.trim() ?? 'Gagal membuat ide pose.';
    } catch (error) {
        console.error("Gemini API model pose generation error:", error);
        throw new Error("Gagal membuat ide pose.");
    }
};

interface ProductModelPackInputs {
    productImage: File;
    modelImage?: File;
    backgroundImage?: File;
    ratio: string;
    gender: string;
    interactionPrompt: string;
    modelClothing: string;
    language: string;
}

export const generateProductModelPack = async (
    inputs: ProductModelPackInputs,
    onBatchComplete: (batchResults: { theme: string, imageUrl: string }[]) => void,
    onDnaComplete: (dna: string) => void,
    onProgress: (message: string) => void,
    signal: AbortSignal
): Promise<void> => {
    const { productImage, modelImage, backgroundImage, ratio, gender, interactionPrompt, modelClothing } = inputs;

    let visualDNA = '';
    if (modelImage) {
        try {
            onProgress('Memindai DNA Visual model...');
            visualDNA = await generateCharacterDNA(modelImage);
            onDnaComplete(visualDNA);
        } catch (e) {
            console.error("Tidak dapat membuat DNA visual untuk model.", e);
            onProgress('Gagal memindai DNA. Melanjutkan tanpa DNA.');
        }
    }
    
    if (signal.aborted) return;


    const POSES_PER_THEME = [
        "Pose percaya diri dan ceria, tertawa sambil melihat sedikit menjauh dari kamera.",
        "Pose aksi dinamis, seolah-olah ditangkap di tengah gerakan saat berinteraksi secara alami dengan produk.",
        "Pose gaya hidup kasual dan santai, bersandar di suatu permukaan atau duduk dengan nyaman.",
        "Fokus close-up pada interaksi model dengan produk, menunjukkan detail dan tekstur.",
    ];

    const THEMES = [
        { name: "Studio Minimalis", style: "Studio minimalis yang bersih dengan pencahayaan lembut dan menyebar." },
        { name: "Jalanan Kota Malam Hari", style: "Jalanan kota yang ramai di malam hari dengan lampu neon dan efek bokeh yang indah." },
        { name: "Interior Mewah", style: "Latar dalam ruangan yang mewah seperti lobi hotel modern atau apartemen kelas atas." },
        { name: "Alam Terbuka saat Senja", style: "Lingkungan alam terbuka, seperti hutan atau padang bunga saat golden hour." },
        { name: "Futuristik & Fiksi Ilmiah", style: "Latar futuristik fiksi ilmiah dengan garis-garis bersih, permukaan metalik, dan pencahayaan bernuansa dingin." },
        { name: "Kafe yang Hangat & Nyaman", style: "Suasana kafe yang hangat dan nyaman dengan nuansa kayu yang kaya atau kabin dengan perapian." },
        { name: "Latar Artistik Abstrak", style: "Latar belakang artistik abstrak dengan warna-warna komplementer yang berani dan bentuk geometris." },
        { name: "Pemandangan Pantai yang Cerah", style: "Pemandangan pantai yang cerah dengan air biru jernih, pasir putih, dan pohon kelapa." },
        { name: "Gaya Hidup Perkotaan", style: "Gaya hidup perkotaan, di apartemen modern dengan pemandangan kota." },
        { name: "Taman Bunga Musim Semi", style: "Taman yang dipenuhi bunga-bunga bermekaran, pencahayaan alami yang cerah." },
        { name: "Perpustakaan Klasik", style: "Perpustakaan dengan rak buku dari lantai ke langit-langit, suasana yang tenang dan terpelajar." },
        { name: "Pasar Tradisional yang Ramai", style: "Pasar tradisional yang penuh warna dan ramai, menunjukkan kehidupan sehari-hari." },
        { name: "Atap Gedung saat Matahari Terbenam", style: "Di atap gedung pencakar langit saat matahari terbenam, dengan pemandangan kota yang luas." },
        { name: "Dapur Modern", style: "Di dapur modern yang bersih dan lengkap, menunjukkan penggunaan produk dalam konteks rumah." },
        { name: "Galeri Seni Kontemporer", style: "Galeri seni dengan dinding putih bersih dan karya seni modern sebagai latar belakang." },
        { name: "Suasana Hutan Hujan Tropis", style: "Hutan hujan yang lebat dengan tanaman hijau subur dan cahaya yang menembus kanopi." },
        { name: "Pesta di Malam Hari", style: "Suasana pesta yang elegan dengan lampu berkelip dan orang-orang di latar belakang." },
        { name: "Tepi Kolam Renang Mewah", style: "Di tepi kolam renang di sebuah vila mewah, suasana santai dan premium." },
        { name: "Interior Gaya Skandinavia", style: "Interior dengan desain Skandinavia, dominasi warna putih, kayu terang, dan tanaman hias." },
        { name: "Petualangan Mendaki Gunung", style: "Di jalur pendakian gunung, dengan pemandangan pegunungan yang megah." },
    ];
    
    const TOTAL_IMAGES = 80;
    const allPrompts: { theme: string, prompt: string }[] = [];
    
    for (let i = 0; i < TOTAL_IMAGES; i++) {
        const themeIndex = Math.floor(i / POSES_PER_THEME.length);
        const poseIndex = i % POSES_PER_THEME.length;
        
        const currentTheme = THEMES[themeIndex];
        const currentPose = POSES_PER_THEME[poseIndex];
        const genderString = gender === 'Wanita' ? 'female' : gender === 'Pria' ? 'male' : 'person';
        const style = backgroundImage ? 'Sesuai dengan latar belakang yang diberikan pengguna' : currentTheme.style;

        const fullPrompt = `
            ABSOLUTELY CRITICAL: Buat sebuah foto komersial yang hiper-realistis, kualitas 8k. **Ini harus berupa bidikan seluruh tubuh, menampilkan model dari kepala hingga kaki.**
            **Fokus utama dan pahlawan dalam foto ini adalah produk.** Produk harus diterangi dengan sempurna dan dalam fokus yang tajam.
            **ATURAN PALING KRUSIAL: Produk yang ditampilkan dalam gambar referensi HARUS digunakan PERSIS SEPERTI ADANYA. JANGAN PERNAH mengubah desain, warna, merek, atau detail apa pun. Tugas AI adalah mengintegrasikan produk yang sama persis dari gambar ke dalam adegan baru, BUKAN menata ulang produk itu sendiri.**
            Seorang model ${genderString} hadir untuk melengkapi produk, bukan menutupi.
            Model mengenakan: **${modelClothing}**. Pakaian ini harus tetap sama persis di setiap gambar yang dihasilkan.
            ${visualDNA ? `**SANGAT PENTING:** Wajah, rambut, dan tipe tubuh model HARUS secara ketat mematuhi deskripsi ini (DNA visual): ${visualDNA}. Sangat penting bahwa model terlihat seperti orang yang sama dari foto referensi yang diberikan.` : ''}
            Gaya dan Suasana: ${style}.
            Interaksi model dengan produk: "${interactionPrompt}".
            Pose Model: "${currentPose}".
            ${backgroundImage ? '**KRUSIAL:** Tempatkan model dan produk secara alami ke dalam gambar latar belakang yang disediakan. Pencahayaan, bayangan, dan gradasi warna pada model dan produk HARUS sangat cocok dengan latar belakang untuk menciptakan komposit yang mulus dan realistis.' : ''}
            Gaya Fotografi: Format foto RAW. Diambil dengan DSLR profesional (seperti Sony A7 IV) dengan lensa 85mm f/1.4 yang tajam, menciptakan depth of field yang sangat dangkal dan bokeh yang indah. Pencahayaan sinematik dan lembut, dibuat dengan cermat untuk menciptakan sorotan dan bayangan realistis. Tekankan tekstur hiper-realistis: pori-pori kulit alami, tenunan halus kain, dan permukaan material yang presisi.
            Instruksi Kritis: Hasil akhir HARUS sama sekali tidak bisa dibedakan dari foto asli beranggaran tinggi. Sama sekali TIDAK boleh ada "tampilan AI", kulit seperti plastik, atau fitur yang terlalu halus. Pastikan anatomi manusia realistis.
        `;
        allPrompts.push({ theme: currentTheme.name, prompt: fullPrompt });
    }

    const BATCH_SIZE = 8;
    for (let i = 0; i < allPrompts.length; i += BATCH_SIZE) {
        if (signal.aborted) {
            console.log("Proses dibatalkan oleh pengguna.");
            break;
        }
        const batch = allPrompts.slice(i, i + BATCH_SIZE);
        onProgress(`Memproses batch ${i/BATCH_SIZE + 1}/${allPrompts.length/BATCH_SIZE}... (${i + batch.length}/${TOTAL_IMAGES} foto)`);

        try {
            const imagePromises = batch.map(p => 
                generateProductImage(
                    p.prompt,
                    productImage,
                    ratio,
                    modelImage,
                    undefined,
                    backgroundImage,
                    signal
                ).then(imageUrl => ({ theme: p.theme, imageUrl }))
            );

            const batchResults = await Promise.all(imagePromises);
            onBatchComplete(batchResults);
        } catch (error: any) {
            if (error.name === 'AbortError') {
                 console.log("Batch dibatalkan oleh pengguna.");
                 break;
            }
            console.error(`Gagal memproses batch ${i/BATCH_SIZE + 1}:`, error);
            throw new Error(`Gagal pada batch ${i/BATCH_SIZE + 1}. Silakan periksa prompt atau coba lagi.`);
        }
    }
};

export const generateInteractionPrompt = async (productImage: File): Promise<string> => {
    const ai = getGoogleAI();
    const imagePart = await fileToGenerativePart(productImage);
    const metaPrompt = `Anda adalah seorang pengarah kreatif ahli untuk foto produk. Berdasarkan gambar produk yang diberikan, buatlah satu ide prompt interaksi model yang singkat, kreatif, dan menjual dalam Bahasa Indonesia.

Instruksi:
1. Pertimbangkan jenis produk (misalnya kemewahan, olahraga, anak-anak) dan bagaimana model akan menggunakannya secara otentik.
2. Prompt harus membangkitkan emosi atau menceritakan sebuah mini-cerita.
3. Keluaran harus berupa satu kalimat pendek yang cocok untuk dimasukkan ke dalam prompt generator gambar.

Contoh keluaran: "model tersenyum puas saat merasakan tekstur krim di pipinya", "model tertawa lepas saat menyemprotkan parfum ke udara", "model dengan tatapan fokus menuangkan serum ke tangannya".

Hanya kembalikan deskripsi aksinya saja, tanpa kalimat pembuka atau penutup.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: { parts: [imagePart, { text: metaPrompt }] },
        });
        return response.text?.trim() ?? 'Gagal membuat ide interaksi.';
    } catch (error) {
        console.error("Gemini API interaction prompt generation error:", error);
        throw new Error("Gagal membuat ide interaksi.");
    }
};

export const generateDialoguePrompt = async (interactionPrompt: string, language: string): Promise<string> => {
    const ai = getGoogleAI();
    const metaPrompt = `
    Anda adalah seorang penulis naskah kreatif untuk iklan video di media sosial. Berdasarkan deskripsi adegan berikut, buatlah satu dialog yang singkat dan terdengar alami dalam Bahasa ${language}. Dialog ini akan diucapkan oleh model dalam iklan.

    Deskripsi Adegan: "${interactionPrompt}"

    Instruksi:
    1. Dialog harus berupa satu kalimat yang berdampak.
    2. Dialog harus terdengar otentik dan mencerminkan emosi dari adegan tersebut.
    3. Buat dialog yang sesuai dengan adegan.
    4. Hasilkan HANYA teks dialognya, tanpa label seperti "DIALOG:".

    Contoh:
    - Deskripsi Adegan: "model tertawa saat mengaplikasikan produk perawatan kulit"
    - Bahasa: Indonesia
    - Contoh Keluaran: "Gak nyangka, kulit jadi secerah ini!"
    `;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: metaPrompt,
        });
        return response.text?.trim() ?? 'Gagal membuat dialog.';
    } catch (error) {
        console.error("Gemini API dialogue prompt generation error:", error);
        throw new Error("Gagal membuat dialog.");
    }
};