import React from 'react';
import type { Feature } from './types';
import { ImageIcon } from './components/icons/ImageIcon';
import { SoundIcon } from './components/icons/SoundIcon';
import { WandIcon } from './components/icons/WandIcon';
import { CharacterIcon } from './components/icons/CharacterIcon';
import { ProductIcon } from './components/icons/ProductIcon';
import { FoodIcon } from './components/icons/FoodIcon';
import { AnimationIcon } from './components/icons/AnimationIcon';
import { FilmSlateIcon } from './components/icons/FilmSlateIcon';
import { AffiliateIcon } from './components/icons/AffiliateIcon';
import { LinkIcon } from './components/icons/LinkIcon';

export enum FeatureID {
  ImageGenerator = 'image-generator',
  TextToSpeech = 'text-to-speech',
  PhotoPromptGenerator = 'photo-prompt-generator',
  ProductWithModel = 'product-with-model',
  FoodPhotography = 'food-photography',
  BlueprintGenerator = 'blueprint-generator',
  VideoSceneCreator = 'video-scene-creator',
  AffiliateContent = 'affiliate-content',
  ManageLinks = 'manage-links',
}

export const FEATURES: Feature[] = [
  {
    id: FeatureID.ImageGenerator,
    name: "Image Generator",
    description: "Generate stunning images from text descriptions.",
    icon: ImageIcon,
    outputType: 'image',
    promptPlaceholder: 'Contoh: Seekor singa megah di hutan bersalju',
    model: 'gemini-2.5-flash-image',
  },
  {
    id: FeatureID.TextToSpeech,
    name: "Text to Speech",
    description: "Convert your text into natural-sounding speech.",
    icon: SoundIcon,
    outputType: 'audio',
    promptPlaceholder: 'Masukkan teks untuk diubah menjadi suara...',
    model: 'gemini-2.5-flash-preview-tts',
  },
  {
    id: FeatureID.AffiliateContent,
    name: "Affiliate Content",
    description: "Generate a pack of content for affiliate marketing.",
    icon: AffiliateIcon,
    outputType: 'image',
    promptPlaceholder: '', // Complex UI
    model: 'gemini-2.5-flash-image',
  },
  {
    id: FeatureID.ProductWithModel,
    name: "Product w/ Model",
    description: "Combine product shots with professional models.",
    icon: ProductIcon,
    outputType: 'image',
    promptPlaceholder: '', // This component has its own complex UI
    model: 'gemini-2.5-flash-image',
  },
  {
    id: FeatureID.PhotoPromptGenerator,
    name: "Photo Prompt AI",
    description: "Generate detailed and creative prompts for AI image generators.",
    icon: WandIcon,
    outputType: 'text',
    promptPlaceholder: 'Contoh: Seorang astronot di hutan fantasi',
    model: 'gemini-3-flash-preview',
  },
  {
    id: FeatureID.BlueprintGenerator,
    name: "Animation Scene Generator",
    description: "Create scenes for an animated story with consistent characters.",
    icon: AnimationIcon,
    outputType: 'image',
    promptPlaceholder: '', // Complex UI
    model: 'gemini-2.5-flash-image',
  },
  {
    id: FeatureID.VideoSceneCreator,
    name: "Video Scene Creator",
    description: "Generate short video clips using Veo 3.",
    icon: FilmSlateIcon,
    outputType: 'video',
    promptPlaceholder: '', // Complex UI
    model: 'veo-3.1-fast-generate-preview',
  },
  {
    id: FeatureID.FoodPhotography,
    name: "Food Photo AI",
    description: "Generate professional photos for food products.",
    icon: FoodIcon,
    outputType: 'image',
    promptPlaceholder: '', // Complex UI
    model: 'gemini-2.5-flash-image',
  },
  {
    id: FeatureID.ManageLinks,
    name: "FX Flow Tool",
    description: "Akses tool FX Flow dari Google Labs.",
    icon: LinkIcon,
    outputType: 'text', // Not used, but required by type
    promptPlaceholder: '', // Complex UI
    model: '', // No model needed
    externalLink: 'https://labs.google/fx/tools/flow',
  },
];