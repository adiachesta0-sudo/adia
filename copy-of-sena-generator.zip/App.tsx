import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import { FEATURES, FeatureID } from './constants';
import { MenuIcon } from './components/icons/MenuIcon';

// Import all feature components
import TextToSpeechGenerator from './components/TextToSpeechGenerator';
import ImageGenerator from './components/ImageGenerator';
import PhotoPromptGenerator from './components/PhotoPromptGenerator';
import ProductWithModelGenerator from './components/ProductWithModelGenerator';
import FoodPhotoGenerator from './components/FoodPhotoGenerator';
import BlueprintGenerator from './components/BlueprintGenerator';
import VideoSceneCreator from './components/VideoSceneCreator';
import AffiliateContentGenerator from './components/AffiliateContentGenerator';
import ManageLinks from './components/ManageLinks';

// Map FeatureID to its corresponding component for easier rendering
const featureComponentMap: Record<FeatureID, React.ComponentType<any>> = {
  [FeatureID.TextToSpeech]: TextToSpeechGenerator,
  [FeatureID.ImageGenerator]: ImageGenerator,
  [FeatureID.PhotoPromptGenerator]: PhotoPromptGenerator,
  [FeatureID.ProductWithModel]: ProductWithModelGenerator,
  [FeatureID.FoodPhotography]: FoodPhotoGenerator,
  [FeatureID.BlueprintGenerator]: BlueprintGenerator,
  [FeatureID.VideoSceneCreator]: VideoSceneCreator,
  [FeatureID.AffiliateContent]: AffiliateContentGenerator,
  [FeatureID.ManageLinks]: AffiliateContentGenerator, // Fallback for external link
};


const App: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<FeatureID>(FeatureID.ImageGenerator);
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-black text-gray-300 font-sans">
      <Sidebar 
        activeFeature={activeFeature} 
        setActiveFeature={setActiveFeature} 
        isSidebarOpen={isSidebarOpen}
        setSidebarOpen={setSidebarOpen} 
      />
      
      <main className="flex-1 flex flex-col transition-all duration-300">
        <header className="flex items-center p-4 bg-gray-900/80 backdrop-blur-sm border-b border-gray-800 md:hidden">
            <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 rounded-md hover:bg-gray-700">
                <MenuIcon />
            </button>
            <h1 className="text-xl font-bold ml-4 text-white">SENA GENERATOR</h1>
        </header>

        <div className="flex-1 overflow-y-auto">
            {FEATURES.map(feature => {
              // Don't render a component for external links
              if (feature.externalLink) return null;
              
              const Component = featureComponentMap[feature.id];
              return (
                <div key={feature.id} hidden={activeFeature !== feature.id} className="h-full">
                  <Component />
                </div>
              );
            })}
        </div>
      </main>
    </div>
  );
};

export default App;