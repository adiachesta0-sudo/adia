
import React, { useState } from 'react';
import { UserIcon } from './icons/UserIcon';
import { LockIcon } from './icons/LockIcon';
import { LightningIcon } from './icons/LightningIcon';

interface LoginScreenProps {
    onLoginSuccess: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (username === 'sena' && password === 'sena123') {
            onLoginSuccess();
        } else {
            setError('Nama pengguna atau kata sandi salah.');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-black text-gray-300 font-sans">
            <div className="w-full max-w-sm p-8 space-y-8 bg-gray-900 rounded-2xl shadow-lg border border-gray-800">
                <div className="text-center">
                    <div className="flex justify-center items-center gap-2 mb-2">
                        <LightningIcon className="w-8 h-8 text-purple-500"/>
                        <h1 className="text-3xl font-bold text-white">SENA GENERATOR</h1>
                    </div>
                    <p className="text-gray-500">Silakan masuk untuk melanjutkan</p>
                </div>
                <form className="space-y-6" onSubmit={handleLogin}>
                    <div>
                        <label htmlFor="username" className="text-sm font-bold text-gray-400 block mb-2">
                            Nama Pengguna
                        </label>
                        <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                                <UserIcon className="h-5 w-5 text-gray-500" />
                            </span>
                            <input
                                id="username"
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                placeholder="sena"
                            />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="password"  className="text-sm font-bold text-gray-400 block mb-2">
                           Kata Sandi
                        </label>
                        <div className="relative">
                             <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                                <LockIcon className="h-5 w-5 text-gray-500" />
                            </span>
                            <input
                                id="password"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                placeholder="sena123"
                            />
                        </div>
                    </div>

                    {error && (
                         <p className="text-sm text-red-400 text-center animate-fadeInDown">{error}</p>
                    )}

                    <div>
                        <button
                            type="submit"
                            className="w-full px-4 py-3 font-bold text-white bg-purple-600 rounded-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500 transition-colors"
                        >
                            Masuk
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default LoginScreen;
