import React, { useState, useRef } from 'react';
import Spinner from './Spinner';
import * as geminiService from '../services/geminiService';
import { ProductIcon } from './icons/ProductIcon';
import { UploadIcon } from './icons/UploadIcon';
import { UserIcon } from './icons/UserIcon';
import { CheckIcon } from './icons/CheckIcon';
import { PencilIcon } from './icons/PencilIcon';
import { PlusIcon } from './icons/PlusIcon';
import { GalleryIcon } from './icons/GalleryIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import FullscreenModal from './FullscreenModal';
import { TextIcon } from './icons/TextIcon';
import { WandIcon } from './icons/WandIcon';
import { LandscapeIcon } from './icons/LandscapeIcon';
import { LockIcon } from './icons/LockIcon';
import type { GeneratedTheme } from '../types';
import { StopIcon } from './icons/StopIcon';


type Ratio = '3:4' | '1:1' | '4:3' | '9:16' | '16:9';
type Gender = 'Wanita' | 'Pria' | 'Mix';

interface FilePreview {
    file: File;
    previewUrl: string;
}

const ProductWithModelGenerator: React.FC = () => {
    const [productImage, setProductImage] = useState<FilePreview | null>(null);
    const [modelImage, setModelImage] = useState<FilePreview | null>(null);
    const [backgroundImage, setBackgroundImage] = useState<FilePreview | null>(null);
    const [ratio, setRatio] = useState<Ratio>('3:4');
    const [gender, setGender] = useState<Gender>('Wanita');
    const [prompt, setPrompt] = useState('Model memegang botol di dekat pipi...');
    const [modelClothing, setModelClothing] = useState('Kemeja putih dan celana jeans biru');
    const [language, setLanguage] = useState('Indonesia');
    
    // Loading States
    const [isLoading, setIsLoading] = useState(false);
    const [isInteractionLoading, setIsInteractionLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');

    const [error, setError] = useState<string | null>(null);
    
    // Result States
    const [generatedThemes, setGeneratedThemes] = useState<GeneratedTheme[]>([]);
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

    const abortControllerRef = useRef<AbortController | null>(null);

    const handleFile = (file: File | null, setter: React.Dispatch<React.SetStateAction<FilePreview | null>>) => {
        if (!file) return;
        setter({ file, previewUrl: URL.createObjectURL(file) });
    };

    const handleGenerate = async () => {
        if (!productImage) {
            setError('Upload Produk (Wajib)');
            return;
        }
        
        abortControllerRef.current = new AbortController();
        const signal = abortControllerRef.current.signal;

        setIsLoading(true);
        setError(null);
        setGeneratedThemes([]);
        setStatusMessage('Memulai proses...');
        
        try {
            const onBatchComplete = (batchResults: { theme: string, imageUrl: string }[]) => {
                setGeneratedThemes(prevThemes => {
                    const themesMap = new Map<string, string[]>();
                    prevThemes.forEach(theme => themesMap.set(theme.theme, theme.images));
                    batchResults.forEach(result => {
                        if (!themesMap.has(result.theme)) {
                            themesMap.set(result.theme, []);
                        }
                        themesMap.get(result.theme)!.push(result.imageUrl);
                    });
                    return Array.from(themesMap, ([theme, images]) => ({ theme, images }));
                });
            };
            
            const onDnaComplete = (dna: string) => {
                setStatusMessage('DNA Visual model berhasil dipindai. Memulai pembuatan gambar...');
            };

            await geminiService.generateProductModelPack({
                productImage: productImage.file,
                modelImage: modelImage?.file,
                backgroundImage: backgroundImage?.file,
                ratio,
                gender,
                interactionPrompt: prompt,
                modelClothing,
                language,
            }, onBatchComplete, onDnaComplete, setStatusMessage, signal);
            
            if (!signal.aborted) {
                 setStatusMessage('Selesai! 80 foto berhasil dibuat.');
            }

        } catch (e: any) {
            if (e.name === 'AbortError') {
                console.log('Generation was aborted.');
                setStatusMessage('Proses dihentikan oleh pengguna.');
                setError(null);
            } else {
                setError(e.message || 'An unexpected error occurred.');
            }
        } finally {
            setIsLoading(false);
            abortControllerRef.current = null;
        }
    };

    const handleStop = () => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            setStatusMessage('Menghentikan proses...');
            setIsLoading(false);
        }
    };

    const handleGenerateInteraction = async () => {
        if (!productImage) {
            setError('Upload Foto Produk terlebih dahulu untuk membuat ide interaksi.');
            return;
        }
        setIsInteractionLoading(true);
        setError(null);
        try {
            const interactionIdea = await geminiService.generateInteractionPrompt(productImage.file);
            setPrompt(interactionIdea);
        } catch (e: any) {
            setError(e.message || 'Gagal membuat ide interaksi.');
        } finally {
            setIsInteractionLoading(false);
        }
    };

    const FileUploadArea = ({ icon, title, subtitle, file, onFileSelected, error }: any) => {
        const inputRef = useRef<HTMLInputElement>(null);
        const [isDragging, setIsDragging] = useState(false);

        const onDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
        const onDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(false); };
        const onDrop = (e: React.DragEvent) => {
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                onFileSelected(e.dataTransfer.files[0]);
            }
        };

        const baseClasses = "bg-gray-800 p-4 rounded-lg h-full flex flex-col items-center justify-center text-center border-2 border-dashed transition-colors cursor-pointer group relative min-h-[120px]";
        const borderClasses = error ? 'border-red-500' : isDragging ? 'border-purple-500' : 'border-gray-600 hover:border-gray-500';
        const fileUploadedClasses = file ? 'border-purple-500' : '';

        return (
            <div 
                className={`${baseClasses} ${borderClasses} ${fileUploadedClasses}`}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
                onClick={() => inputRef.current?.click()}
            >
                 <input type="file" accept="image/*" ref={inputRef} onChange={(e) => onFileSelected(e.target.files?.[0] || null)} className="hidden"/>
                {file ? (
                     <>
                        <img src={file.previewUrl} alt="Preview" className="max-h-24 w-auto object-contain rounded-md"/>
                        <div className="absolute inset-0 bg-black/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-white font-semibold">Ganti File</span>
                        </div>
                     </>
                ): (
                    <>
                        <div className={`transition-transform group-hover:scale-110 ${isDragging ? 'scale-110' : ''}`}>
                            {icon}
                        </div>
                        <p className="font-semibold mt-2 text-xs text-gray-200">{title}</p>
                        {subtitle && <p className="text-xs text-gray-400">{subtitle}</p>}
                    </>
                )}
            </div>
        );
    };
    
    const totalGeneratedImages = generatedThemes.reduce((acc, theme) => acc + theme.images.length, 0);

    return (
        <>
            <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
            <div className="flex-1 p-4 sm:p-6 lg:p-8 flex flex-col md:flex-row gap-8 bg-black text-gray-300">
                {/* Left Control Panel */}
                <div className="w-full md:w-2/5 xl:w-1/3 flex flex-col gap-5">
                    <header className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-purple-600 rounded-md">
                            <ProductIcon className="w-6 h-6 text-white"/>
                        </div>
                        <div>
                            <h1 className="text-xl font-bold text-white">Product With Model</h1>
                            <p className="text-xs text-gray-500">Menyatukan produk dan model</p>
                        </div>
                    </header>
                    
                    {/* Control Sections */}
                    <div className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                             <div>
                                <div className="flex items-center gap-2 mb-2">
                                <UploadIcon className="w-5 h-5 text-purple-500"/>
                                <h3 className="font-bold text-gray-200 text-sm">1. Produk (Wajib)</h3>
                                </div>
                                <FileUploadArea 
                                    icon={<UploadIcon className="w-8 h-8 text-gray-500"/>}
                                    title="Foto Produk"
                                    file={productImage}
                                    onFileSelected={(f: File) => handleFile(f, setProductImage)}
                                    error={error && !productImage}
                                />
                            </div>
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <UserIcon className="w-5 h-5 text-purple-500"/>
                                    <h3 className="font-bold text-gray-200 text-sm">2. Model (Opsional)</h3>
                                </div>
                                <FileUploadArea 
                                    icon={<UserIcon className="w-8 h-8 text-gray-500"/>}
                                    title="Wajah/Model"
                                    file={modelImage}
                                    onFileSelected={(f: File) => handleFile(f, setModelImage)}
                                />
                            </div>
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <LandscapeIcon className="w-5 h-5 text-purple-500"/>
                                    <h3 className="font-bold text-gray-200 text-sm">3. Latar (Opsional)</h3>
                                </div>
                                <FileUploadArea 
                                    icon={<LandscapeIcon className="w-8 h-8 text-gray-500"/>}
                                    title="Foto Latar"
                                    file={backgroundImage}
                                    onFileSelected={(f: File) => handleFile(f, setBackgroundImage)}
                                />
                            </div>
                        </div>

                        <div className="bg-gray-900 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-3">
                                <CheckIcon className="w-5 h-5 text-purple-500"/>
                                <h3 className="font-bold text-gray-200">4. Rasio Foto</h3>
                            </div>
                            <div className="grid grid-cols-5 gap-2">
                                {(['3:4', '1:1', '4:3', '9:16', '16:9'] as Ratio[]).map(r => (
                                <button key={r} onClick={() => setRatio(r)} className={`py-2 rounded text-sm font-semibold transition-colors ${ratio === r ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>{r}</button>
                                ))}
                            </div>
                        </div>

                        <div className="bg-gray-900 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-3">
                                <UserIcon className="w-5 h-5 text-purple-500"/>
                                <h3 className="font-bold text-gray-200">5. Gender & Pakaian Model</h3>
                            </div>
                            <div className="grid grid-cols-3 gap-2">
                                {(['Wanita', 'Pria', 'Mix'] as Gender[]).map(g => (
                                <button key={g} onClick={() => setGender(g)} className={`py-2 rounded text-sm font-semibold transition-colors ${gender === g ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>{g}</button>
                                ))}
                            </div>
                            <div className="mt-3">
                                 <label className="block text-xs font-semibold text-gray-400 mb-1">Pakaian Model</label>
                                 <input 
                                     type="text" 
                                     value={modelClothing} 
                                     onChange={e => setModelClothing(e.target.value)} 
                                     placeholder="Cth: Kemeja putih, celana jeans" 
                                     className="w-full bg-gray-800 border border-gray-600 rounded p-2 text-sm text-white"
                                 />
                            </div>
                        </div>
                        
                        <div className="bg-gray-900 p-4 rounded-lg">
                            <div className="flex items-center justify-between gap-2 mb-3">
                                <div className="flex items-center gap-2">
                                    <PencilIcon className="w-5 h-5 text-purple-500"/>
                                    <h3 className="font-bold text-gray-200">6. Cara Pakai / Interaksi</h3>
                                </div>
                                <button 
                                    onClick={handleGenerateInteraction} 
                                    disabled={isInteractionLoading || !productImage}
                                    className="p-1 text-gray-400 hover:text-purple-400 transition-colors disabled:cursor-not-allowed disabled:text-gray-600"
                                    title="Buat ide interaksi otomatis"
                                >
                                    {isInteractionLoading ? <Spinner className="!w-5 !h-5" /> : <WandIcon className="w-5 h-5" />}
                                </button>
                            </div>
                            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Contoh: Model memegang botol di dekat pipi..." className="w-full bg-gray-800 border border-gray-600 rounded p-2 text-sm focus:ring-1 focus:ring-purple-500 focus:border-purple-500 text-white" rows={2}></textarea>
                        </div>

                         <div className="bg-gray-900 p-4 rounded-lg">
                            <div className="flex items-center gap-2 mb-3">
                                <TextIcon className="w-5 h-5 text-purple-500"/>
                                <h3 className="font-bold text-gray-200">7. Bahasa</h3>
                            </div>
                            <select value={language} onChange={e => setLanguage(e.target.value)} className="custom-select w-full bg-gray-800 border border-gray-600 rounded p-2 text-sm focus:ring-1 focus:ring-purple-500 focus:border-purple-500 text-white">
                                <option>Indonesia</option>
                                <option>English</option>
                            </select>
                        </div>
                    </div>
                     <div className="mt-auto pt-5">
                         {isLoading ? (
                            <button onClick={handleStop} className="w-full flex items-center justify-center gap-2 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition-colors text-lg">
                                <StopIcon className="w-6 h-6"/>
                                Hentikan Generate
                            </button>
                         ) : (
                            <button onClick={handleGenerate} className="w-full flex items-center justify-center gap-2 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed text-lg">
                                <PlusIcon className="w-6 !h-6"/>
                                Generate 80 Foto
                            </button>
                         )}
                        {error && <p className="text-sm text-red-400 text-center mt-2">{error}</p>}
                    </div>
                </div>

                {/* Right Gallery */}
                <div className="w-full md:w-3/5 xl:w-2/3 bg-gray-900 rounded-lg p-4 flex flex-col">
                    <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                            <GalleryIcon className="w-6 h-6 text-purple-500" />
                            <h2 className="text-lg font-semibold text-white">Galeri Hasil ({totalGeneratedImages} / 80 Foto)</h2>
                        </div>
                        {isLoading && <Spinner className="!w-5 !h-5" />}
                    </div>
                     {statusMessage && <p className="text-sm text-purple-400 mb-2 flex items-center gap-2"><LockIcon className="w-4 h-4"/> {statusMessage}</p>}

                    <div className="flex-1 bg-black rounded-md p-4 relative overflow-y-auto">
                        {(isLoading || generatedThemes.length > 0) ? (
                            <div className="space-y-6">
                                {generatedThemes.map((theme, themeIndex) => (
                                    <div key={themeIndex} className="animate-fadeInDown">
                                        <h3 className="font-semibold text-lg text-purple-300 mb-2 border-b border-gray-800 pb-1">{theme.theme}</h3>
                                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                            {theme.images.map((imageUrl, imgIndex) => (
                                                 <div key={imgIndex} className="relative group aspect-square">
                                                    <img src={imageUrl} alt={`Konten ${theme.theme} ${imgIndex + 1}`} className="rounded-lg w-full h-full object-cover" />
                                                    <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <button onClick={() => setFullscreenImage(imageUrl)} className="p-1.5 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Tampilan Penuh"><ExpandIcon className="w-4 h-4" /></button>
                                                        <a href={imageUrl} download={`product-model-${theme.theme}-${imgIndex + 1}.png`} className="p-1.5 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Unduh"><DownloadIcon className="w-4 h-4" /></a>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                                {isLoading && <div className="text-center py-10"><Spinner className="mx-auto !w-10 !h-10"/></div>}
                            </div>
                        ) : (
                            <div className="text-center text-gray-500 px-4 h-full flex flex-col items-center justify-center">
                                <GalleryIcon className="w-16 h-16 mx-auto text-gray-400"/>
                                <h3 className="mt-4 text-xl font-semibold text-gray-300">Belum ada foto</h3>
                                <p className="mt-1 text-sm">Lengkapi pengaturan di sebelah kiri, lalu klik Generate.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

export default ProductWithModelGenerator;