
import React, { useState } from 'react';
import type { CustomLink } from '../types';
import { LinkIcon } from './icons/LinkIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';

interface ManageLinksProps {
    links: CustomLink[];
    setLinks: React.Dispatch<React.SetStateAction<CustomLink[]>>;
}

const ManageLinks: React.FC<ManageLinksProps> = ({ links, setLinks }) => {
    const [name, setName] = useState('');
    const [url, setUrl] = useState('');
    const [error, setError] = useState('');

    const addLink = () => {
        if (!name.trim() || !url.trim()) {
            setError('Nama dan URL tidak boleh kosong.');
            return;
        }
        // Basic URL validation
        try {
            let validUrl = url.trim();
            if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
                validUrl = 'https://' + validUrl;
            }
            new URL(validUrl);
             const newLink: CustomLink = {
                id: Date.now(),
                name,
                url: validUrl,
            };
            setLinks(prevLinks => [...prevLinks, newLink]);
        } catch (_) {
            setError('Silakan masukkan URL yang valid (contoh: google.com).');
            return;
        }

       
        setName('');
        setUrl('');
        setError('');
    };

    const deleteLink = (id: number) => {
        setLinks(prevLinks => prevLinks.filter(link => link.id !== id));
    };

    return (
        <div className="container mx-auto max-w-2xl p-4 sm:p-6 lg:p-8">
            <header className="mb-8">
                <h1 className="text-3xl sm:text-4xl font-bold text-white flex items-center gap-3">
                    <LinkIcon className="w-8 h-8 text-purple-400" />
                    Kelola Tautan
                </h1>
                <p className="text-gray-400 mt-2">Tambah atau hapus tautan eksternal kustom di sidebar Anda.</p>
            </header>

            <div className="bg-gray-800 p-6 rounded-lg shadow-lg space-y-6">
                <h2 className="text-xl font-semibold text-white">Tambah Tautan Baru</h2>
                <div className="space-y-4">
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Nama Tautan (contoh: Google)"
                        className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <input
                        type="text"
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                        placeholder="URL (contoh: google.com)"
                        className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                </div>
                {error && <p className="text-sm text-red-400">{error}</p>}
                <button
                    onClick={addLink}
                    className="w-full flex items-center justify-center gap-2 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg transition-colors"
                >
                    <PlusIcon className="w-5 h-5" />
                    Tambah Tautan
                </button>
            </div>

            <div className="mt-8">
                <h2 className="text-xl font-semibold text-white mb-4">Tautan Saya</h2>
                {links.length > 0 ? (
                    <ul className="space-y-3">
                        {links.map(link => (
                            <li
                                key={link.id}
                                className="flex items-center justify-between bg-gray-800 p-4 rounded-lg animate-fadeInDown"
                            >
                                <div>
                                    <p className="font-semibold text-white">{link.name}</p>
                                    <a href={link.url} target="_blank" rel="noopener noreferrer" className="text-sm text-purple-400 hover:underline truncate">
                                        {link.url}
                                    </a>
                                </div>
                                <button
                                    onClick={() => deleteLink(link.id)}
                                    className="p-2 text-gray-500 hover:text-red-400 hover:bg-gray-700 rounded-full transition-colors"
                                    aria-label={`Hapus ${link.name}`}
                                >
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-gray-500 text-center py-4">Anda belum menambahkan tautan apa pun.</p>
                )}
            </div>
        </div>
    );
};

export default ManageLinks;
