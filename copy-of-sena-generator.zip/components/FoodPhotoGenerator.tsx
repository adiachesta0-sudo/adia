
import React, { useState, useRef } from 'react';
import Spinner from './Spinner';
import * as geminiService from '../services/geminiService';
import { CameraIcon } from './icons/CameraIcon';
import { GalleryIcon } from './icons/GalleryIcon';
import { LayersIcon } from './icons/LayersIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import FullscreenModal from './FullscreenModal';
import { VideoIcon } from './icons/VideoIcon';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';

type Ratio = 'Asli' | '1:1' | '4:5' | '16:9' | '9:16';
type RatioLabel = 'Asli' | '1:1 (Square)' | '4:5 (Portrait)' | '16:9 (Landscape)' | '9:16 (Story)';

const RATIOS: { id: Ratio; label: RatioLabel }[] = [
    { id: 'Asli', label: 'Asli' },
    { id: '1:1', label: '1:1 (Square)' },
    { id: '4:5', label: '4:5 (Portrait)' },
    { id: '16:9', label: '16:9 (Landscape)' },
    { id: '9:16', label: '9:16 (Story)' },
];

const PHOTO_STYLES = [
    `Dark and moody food photography style. The scene is dramatic with strong side lighting (chiaroscuro), creating deep shadows and highlighting textures. The background is dark, perhaps a slate or dark wood surface. Shot with a macro lens, f/2.8, capturing intricate details. Focus is razor-sharp on the main element.`,
    `Bright and airy lifestyle food photography. The scene is flooded with natural, soft daylight from a large window. The background is clean and light (e.g., white marble or light wood). Use a shallow depth of field (f/1.8) to create a dreamy, soft-focus background. The overall mood is fresh, clean, and inviting.`,
    `Vibrant and rustic commercial style. The food is presented on a rustic surface like a wooden cutting board or aged metal tray. Colors are rich and saturated. Lighting is bright but with soft shadows to give a natural feel. Include some fresh ingredients or garnishes around the main dish to tell a story. Shot from a 45-degree angle.`,
    `Top-down flat lay composition (knolling). The dish is the centerpiece, surrounded by neatly arranged ingredients, cutlery, and a napkin on a clean, textured background. Lighting is even and shadowless. The composition is perfectly balanced and geometric. Colors are vibrant and poppy.`
];

interface FilePreview {
    file: File;
    previewUrl: string;
}

const FoodPhotoGenerator: React.FC = () => {
    const [foodImage, setFoodImage] = useState<FilePreview | null>(null);
    const [prompt, setPrompt] = useState('Mie Goreng Pedas dengan topping telur mata sapi');
    const [ratio, setRatio] = useState<Ratio>('Asli');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
    const [videoPrompt, setVideoPrompt] = useState<string | null>(null);
    const [isVideoPromptCopied, setIsVideoPromptCopied] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (file: File | null) => {
        if (file) {
            setFoodImage({ file, previewUrl: URL.createObjectURL(file) });
        }
    };

    const handleGenerate = async () => {
        if (!foodImage) {
            setError('Silakan upload foto asli terlebih dahulu.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setGeneratedImages([]);
        setVideoPrompt(null);
        setIsVideoPromptCopied(false);

        const apiRatio = ratio === 'Asli' ? '1:1' : ratio; // Default to 1:1 if 'Asli' is chosen
        
        try {
            const imagePromises = PHOTO_STYLES.map(style => 
                geminiService.generateProductImage(
                    `A hyper-realistic, professional food photograph of ${prompt}. ${style} The image must look like a real photo taken with a professional DSLR camera, not an AI generation. Pay attention to realistic textures and lighting.`,
                    foodImage.file,
                    apiRatio
                )
            );
            const images = await Promise.all(imagePromises);
            setGeneratedImages(images);

            try {
                const vp = await geminiService.generateVideoPromptFromText(prompt);
                setVideoPrompt(vp);
            } catch (videoError) {
                console.error("Gagal membuat prompt video:", videoError);
            }

        } catch (e: any) {
            setError(e.message || 'Terjadi kesalahan tak terduga.');
        } finally {
            setIsLoading(false);
        }
    };

     const handleCopyVideoPrompt = () => {
        if (videoPrompt) {
            navigator.clipboard.writeText(videoPrompt);
            setIsVideoPromptCopied(true);
            setTimeout(() => setIsVideoPromptCopied(false), 2000);
        }
    };
    
    const UploadArea = () => (
        <div 
            className={`p-4 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${error && !foodImage ? 'border-red-500' : 'border-gray-600 hover:border-gray-500 hover:bg-gray-800'}`}
            onClick={() => fileInputRef.current?.click()}
        >
            <input 
                type="file" 
                accept="image/*" 
                ref={fileInputRef} 
                onChange={(e) => handleFileChange(e.target.files ? e.target.files[0] : null)} 
                className="hidden"
            />
            {foodImage ? (
                 <img src={foodImage.previewUrl} alt="Pratinjau Makanan" className="w-full h-auto object-cover rounded-md" />
            ) : (
                <div className="text-center text-gray-500 py-4">
                    <GalleryIcon className="w-8 h-8 mx-auto mb-2" />
                    <p>Klik untuk upload foto makanan</p>
                </div>
            )}
        </div>
    );

    return (
        <>
            <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
            <div className="bg-black min-h-full text-gray-300">
                <header className="text-center py-10">
                    <div className="inline-flex items-center gap-3">
                        <CameraIcon className="w-8 h-8 text-orange-500" />
                        <h1 className="text-4xl font-bold text-white">FoodProduct AI</h1>
                    </div>
                    <p className="text-gray-400 mt-2">Generator Foto Makanan Profesional: Poster, Cinematic, Resto, Iklan & Model</p>
                </header>

                <div className="flex flex-col lg:flex-row gap-8 px-4 sm:px-8 pb-8">
                    {/* Left Control Panel */}
                    <div className="w-full lg:w-1/3 xl:w-1/4 space-y-6">
                        {/* Step 1: Upload */}
                        <div className="p-5 bg-gray-900 rounded-xl border border-gray-800">
                            <h3 className="font-bold text-gray-200 mb-3">1. Upload Foto Asli</h3>
                            <UploadArea />
                            {error && !foodImage && <p className="text-sm text-red-400 mt-2">{error}</p>}
                        </div>

                        {/* Step 2: Description */}
                        <div className="p-5 bg-gray-900 rounded-xl border border-gray-800">
                            <h3 className="font-bold text-gray-200 mb-3">2. Deskripsi atau Konsep Foto</h3>
                            <textarea 
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="Contoh: Mie Goreng Pedas dengan su..." 
                                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-500 text-white"
                                rows={3}
                            />
                        </div>

                        {/* Step 3: Ratio */}
                        <div className="p-5 bg-gray-900 rounded-xl border border-gray-800">
                            <h3 className="font-bold text-gray-200 mb-3">3. Pilih Rasio Foto</h3>
                            <div className="grid grid-cols-2 gap-2">
                                {RATIOS.map(r => (
                                    <button key={r.id} onClick={() => setRatio(r.id)} className={`px-3 py-2 text-sm rounded-md transition-colors font-semibold ${ratio === r.id ? 'bg-orange-500 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}>
                                        {r.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Step 4: Generate */}
                        <div className="p-5 bg-gray-900 rounded-xl border border-gray-800">
                            <h3 className="font-bold text-gray-200 mb-3">4. Mode Generate</h3>
                            <button 
                                onClick={handleGenerate}
                                disabled={isLoading}
                                className="w-full p-4 rounded-lg text-white font-bold bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {isLoading ? <Spinner /> : 'GENERATE 4 STYLE PACK'}
                            </button>
                            <p className="text-xs text-center text-gray-500 mt-2">Generate 4 Foto (4 Gaya Realistis)</p>
                        </div>
                    </div>

                    {/* Right Gallery */}
                    <div className="w-full lg:w-2/3 xl:w-3/4 min-h-[60vh] rounded-xl border border-gray-800 bg-gray-900 p-4 flex flex-col">
                        <div 
                            className="w-full flex-1 rounded-lg flex items-center justify-center" 
                            style={{ backgroundImage: 'linear-gradient(45deg, #1f2937 25%, transparent 25%), linear-gradient(-45deg, #1f2937 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1f2937 75%), linear-gradient(-45deg, transparent 75%, #1f2937 75%)', backgroundSize: '20px 20px' }}>
                            
                            {isLoading && <Spinner className="!w-16 !h-16" />}
                            
                            {!isLoading && generatedImages.length > 0 && (
                                <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 animate-fadeInDown w-full h-full overflow-y-auto bg-gray-900/90 rounded-lg">
                                    {generatedImages.map((imgSrc, index) => (
                                        <div key={index} className="relative group">
                                            <img src={imgSrc} alt={`Generated Food Image ${index + 1}`} className="w-full h-auto object-cover rounded-lg shadow-md" />
                                            <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => setFullscreenImage(imgSrc)} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white">
                                                    <ExpandIcon className="w-5 h-5" />
                                                </button>
                                                <a href={imgSrc} download={`food-image-${index + 1}.png`} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white">
                                                    <DownloadIcon className="w-5 h-5" />
                                                </a>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {!isLoading && generatedImages.length === 0 && (
                                <div className="text-center text-gray-500 bg-gray-900/90 p-8 rounded-lg">
                                    <LayersIcon className="w-12 h-12 mx-auto mb-4" />
                                    <h3 className="font-bold text-xl text-gray-200">Siap Membuat Foto</h3>
                                    <p className="text-sm">Tekan "GENERATE 4 STYLE PACK" untuk variasi realistis.</p>
                                </div>
                            )}
                            {error && !isLoading && <p className="text-red-400 text-center font-semibold bg-gray-900/90 p-8 rounded-lg">{error}</p>}
                        </div>
                        {videoPrompt && (
                            <div className="mt-4 p-4 bg-gray-800 rounded-lg animate-fadeInDown space-y-2">
                                <h4 className="text-sm font-semibold text-purple-400 flex items-center gap-2"><VideoIcon className="w-5 h-5" />Prompt Video Promosi (Otomatis)</h4>
                                <p className="text-xs text-gray-400 italic whitespace-pre-wrap">{videoPrompt}</p>
                                <button onClick={handleCopyVideoPrompt} className="w-full flex items-center justify-center gap-1.5 py-2 mt-2 bg-gray-600 hover:bg-gray-700 text-white text-xs font-semibold rounded-md transition-colors">
                                    {isVideoPromptCopied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <ClipboardIcon className="w-4 h-4" />}
                                    {isVideoPromptCopied ? 'Tersalin!' : 'Salin Prompt Video'}
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

export default FoodPhotoGenerator;