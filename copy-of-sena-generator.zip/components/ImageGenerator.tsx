import React, { useState } from 'react';
import Spinner from './Spinner';
import * as geminiService from '../services/geminiService';
import { ImageIcon } from './icons/ImageIcon';
import { GalleryIcon } from './icons/GalleryIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import FullscreenModal from './FullscreenModal';
import { VideoIcon } from './icons/VideoIcon';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';

type Ratio = '1:1' | '9:16' | '16:9' | '3:4' | '4:3';
type ArtStyle = 'Fotografi Realistis' | 'Film Sinematik' | 'Lukisan Digital' | 'Gaya Anime' | '3D Render';

const RATIOS: { id: Ratio; label: string }[] = [
    { id: '1:1', label: 'Square' },
    { id: '9:16', label: 'Portrait' },
    { id: '16:9', label: 'Landscape' },
    { id: '3:4', label: 'Portrait 2' },
    { id: '4:3', label: 'Landscape 2' },
];

const ART_STYLES: ArtStyle[] = ['Fotografi Realistis', 'Film Sinematik', 'Lukisan Digital', 'Gaya Anime', '3D Render'];

const ImageGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState('Seekor singa megah di hutan bersalju');
    const [ratio, setRatio] = useState<Ratio>('1:1');
    const [artStyle, setArtStyle] = useState<ArtStyle>('Fotografi Realistis');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [resultImage, setResultImage] = useState<string | null>(null);
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
    const [videoPrompt, setVideoPrompt] = useState<string | null>(null);
    const [showVideoPrompt, setShowVideoPrompt] = useState(false);
    const [isVideoPromptCopied, setIsVideoPromptCopied] = useState(false);

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError('Prompt cannot be empty.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResultImage(null);
        setVideoPrompt(null);
        setShowVideoPrompt(false);
        setIsVideoPromptCopied(false);

        let finalPrompt = prompt;
        switch (artStyle) {
            case 'Fotografi Realistis':
                finalPrompt += ", fotografi profesional, 8k, fokus tajam, detail tinggi, diambil dengan kamera Canon EOS R5 dengan lensa 50mm f/1.2, pencahayaan sinematik, foto RAW, tanpa artefak AI";
                break;
            case 'Film Sinematik':
                finalPrompt += ", cuplikan film sinematik, lensa anamorphic, butiran film halus, pencahayaan moody, kedalaman bidang yang dangkal, gradasi warna seperti film Hollywood";
                break;
            case 'Lukisan Digital':
                finalPrompt += ", lukisan digital, sangat detail, artstation, konsep seni, goresan kuas yang terlihat, matte painting";
                break;
            case 'Gaya Anime':
                 finalPrompt += ", gaya anime, seni kunci, gaya Studio Ghibli, sangat detail, pixiv, makoto shinkai";
                 break;
            case '3D Render':
                 finalPrompt += ", render 3D, octane render, unreal engine 5, pencahayaan sinematik, sangat detail";
                 break;
        }

        try {
            const generatedImage = await geminiService.generateImage(finalPrompt, 'gemini-2.5-flash-image', ratio);
            setResultImage(generatedImage);
            
            try {
                const vp = await geminiService.generateVideoPromptFromText(prompt);
                setVideoPrompt(vp);
            } catch (videoError) {
                console.error("Gagal membuat prompt video:", videoError);
            }

        } catch (e: any) {
            setError(e.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopyVideoPrompt = () => {
        if (videoPrompt) {
            navigator.clipboard.writeText(videoPrompt);
            setIsVideoPromptCopied(true);
            setTimeout(() => setIsVideoPromptCopied(false), 2000);
        }
    };

    return (
        <>
            <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
            <div className="flex-1 p-4 sm:p-6 lg:p-8 flex flex-col md:flex-row gap-8 bg-black text-gray-300">
                {/* Left Control Panel */}
                <div className="w-full md:w-2/5 xl:w-1/3 bg-gray-900 rounded-lg p-6 shadow-md flex flex-col gap-6">
                    <header>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            <ImageIcon className="w-7 h-7 text-purple-400" />
                            Image Generator
                        </h1>
                        <p className="text-sm text-gray-400 mt-1">Hasilkan gambar menakjubkan dari deskripsi teks.</p>
                    </header>
                    
                    <div>
                        <label htmlFor="prompt" className="block text-sm font-semibold text-gray-400 mb-2">Prompt</label>
                        <textarea
                            id="prompt"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Coba juga: Astronot mengendarai kuda di Mars"
                            className="w-full h-36 p-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors text-white"
                        />
                    </div>

                    <div>
                        <label htmlFor="artStyle" className="block text-sm font-semibold text-gray-400 mb-2">Gaya Seni</label>
                         <select
                            id="artStyle"
                            value={artStyle}
                            onChange={(e) => setArtStyle(e.target.value as ArtStyle)}
                            className="custom-select w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                        >
                            {ART_STYLES.map(style => <option key={style} value={style}>{style}</option>)}
                        </select>
                    </div>

                    <div>
                        <h3 className="text-sm font-semibold text-gray-400 mb-3">Rasio Aspek</h3>
                        <div className="grid grid-cols-3 gap-2">
                            {RATIOS.map(r => (
                                <button
                                    key={r.id}
                                    onClick={() => setRatio(r.id)}
                                    className={`py-2 px-3 rounded text-sm font-semibold transition-colors ${ratio === r.id ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}
                                >
                                    {r.id}
                                    <span className="hidden sm:inline"> ({r.label})</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="mt-auto">
                        <button
                            onClick={handleGenerate}
                            disabled={isLoading}
                            className="w-full flex items-center justify-center gap-2 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed text-lg"
                        >
                            {isLoading ? <Spinner className="!w-6 !h-6" /> : 'Generate'}
                        </button>
                        {error && <p className="text-sm text-red-400 text-center mt-2">{error}</p>}
                    </div>
                </div>

                {/* Right Gallery */}
                <div className="w-full md:w-3/5 xl:w-2/3 bg-gray-900/50 rounded-lg p-4 flex flex-col border border-gray-800">
                    <div className="flex-1 bg-black rounded-md flex items-center justify-center p-4">
                        {isLoading ? <Spinner className="!w-12 !h-12"/> : null}
                        {error && !isLoading && (
                            <div className="text-center text-red-400 px-4">
                                <h3 className="mt-4 text-xl font-semibold">Gagal Membuat Gambar</h3>
                                <p className="mt-1 text-sm">{error}</p>
                            </div>
                        )}
                        {!isLoading && !error && resultImage && (
                             <div className="relative group animate-fadeInDown w-full h-full flex items-center justify-center">
                                <img src={resultImage} alt="Generated" className="max-h-full max-w-full object-contain rounded-md shadow-2xl"/>
                                <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    {videoPrompt && (
                                        <button onClick={() => setShowVideoPrompt(prev => !prev)} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Buat Prompt Video">
                                            <VideoIcon className="w-5 h-5" />
                                        </button>
                                    )}
                                    <button onClick={() => setFullscreenImage(resultImage)} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white">
                                        <ExpandIcon className="w-5 h-5" />
                                    </button>
                                    <a href={resultImage} download="generated-image.png" className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white">
                                        <DownloadIcon className="w-5 h-5" />
                                    </a>
                                </div>
                            </div>
                        )}
                        {!isLoading && !error && !resultImage && (
                            <div className="text-center text-gray-500 px-4">
                                <GalleryIcon className="w-16 h-16 mx-auto text-gray-600"/>
                                <h3 className="mt-4 text-xl font-semibold text-gray-400">Gambar Anda akan muncul di sini</h3>
                                <p className="mt-1 text-sm">Masukkan prompt dan klik Generate.</p>
                            </div>
                        )}
                    </div>
                    {showVideoPrompt && videoPrompt && (
                        <div className="mt-4 p-4 bg-gray-800 rounded-lg animate-fadeInDown space-y-2">
                             <h4 className="text-sm font-semibold text-purple-400">Prompt Video Promosi (Otomatis)</h4>
                             <p className="text-xs text-gray-400 italic whitespace-pre-wrap">{videoPrompt}</p>
                             <button onClick={handleCopyVideoPrompt} className="w-full flex items-center justify-center gap-1.5 py-2 mt-2 bg-gray-600 hover:bg-gray-700 text-white text-xs font-semibold rounded-md transition-colors">
                                {isVideoPromptCopied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <ClipboardIcon className="w-4 h-4" />}
                                {isVideoPromptCopied ? 'Tersalin!' : 'Salin Prompt Video'}
                             </button>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default ImageGenerator;