
import React, { useState, useRef } from 'react';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';
import { UserIcon } from './icons/UserIcon';
import { UploadIcon } from './icons/UploadIcon';
import { LockIcon } from './icons/LockIcon';
import { LandscapeIcon } from './icons/LandscapeIcon';
import { PortraitIcon } from './icons/PortraitIcon';
import { SquareIcon } from './icons/SquareIcon';
import { WandIcon } from './icons/WandIcon';
import { AnimationIcon } from './icons/AnimationIcon';
import { GalleryIcon } from './icons/GalleryIcon';
import { PlusIcon } from './icons/PlusIcon';
import FullscreenModal from './FullscreenModal';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import { TrashIcon } from './icons/TrashIcon';

interface FilePreview {
    file: File;
    previewUrl: string;
}

interface Scene {
  id: number;
  title: string;
  visualPrompt: string;
}

type Ratio = 'Landscape' | 'Portrait' | 'Square';
type ArtStyle = '3D Disney Pixar Style' | 'Japanese Anime (Ghibli Style)' | '3D Realistic Cinematic' | 'Claymation (Stop Motion)' | 'Low Poly 3D' | 'Watercolor Animation';

const RATIOS: { id: Ratio; label: string; sublabel: string; icon: React.FC<{className?: string}> }[] = [
    { id: 'Landscape', label: 'Landscape', sublabel: '16:9', icon: LandscapeIcon },
    { id: 'Portrait', label: 'Portrait', sublabel: '9:16', icon: PortraitIcon },
    { id: 'Square', label: 'Square', sublabel: '1:1', icon: SquareIcon },
];

const ART_STYLES: { id: ArtStyle; description: string }[] = [
    { id: '3D Disney Pixar Style', description: 'Cute, vibrant, expressive, high detail, 3D render' },
    { id: 'Japanese Anime (Ghibli Style)', description: '2D, hand-drawn, lush backgrounds, soft colors, cel shaded' },
    { id: '3D Realistic Cinematic', description: 'Unreal Engine 5 style, hyper-realistic, dramatic lighting, 8k' },
    { id: 'Claymation (Stop Motion)', description: 'Plasticine texture, Aardman style, tactile feel, handmade' },
    { id: 'Low Poly 3D', description: 'Minimalist, angular, retro video game aesthetic, geometric' },
    { id: 'Watercolor Animation', description: 'Soft edges, painterly, artistic, dreamy, wet brush texture, paper texture' },
];

const StepHeader: React.FC<{ number: number; title: string; children: React.ReactNode }> = ({ number, title, children }) => (
    <div className="bg-gray-900/50 p-5 rounded-lg border border-gray-700">
        <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-600 text-white font-bold text-sm">{number}</div>
            <h3 className="text-lg font-bold text-white">{title}</h3>
        </div>
        <div className="space-y-4 pl-11">
            {children}
        </div>
    </div>
);


const BlueprintGenerator: React.FC = () => {
    // Blueprint State
    const [characterRef, setCharacterRef] = useState<FilePreview | null>(null);
    const [visualDNA, setVisualDNA] = useState('');
    const [characterName, setCharacterName] = useState('Budi');
    const [topClothing, setTopClothing] = useState('Kaos merah polos');
    const [bottomClothing, setBottomClothing] = useState('Celana pendek biru jeans');
    const [ratio, setRatio] = useState<Ratio>('Landscape');
    const [artStyle, setArtStyle] = useState<ArtStyle>('3D Disney Pixar Style');
    const [isScanning, setIsScanning] = useState(false);

    // Story State
    const [storyIdea, setStoryIdea] = useState('Budi menemukan peta harta karun ajaib');
    const [scenes, setScenes] = useState<Scene[]>([]);
    const [isStoryLoading, setIsStoryLoading] = useState(false);

    // Generation State
    const [generatedImages, setGeneratedImages] = useState<Record<number, string>>({});
    const [isImageLoading, setIsImageLoading] = useState<Record<number, boolean>>({});
    const [error, setError] = useState<string | null>(null);
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = async (file: File | null) => {
        if (!file) return;
        setCharacterRef({ file, previewUrl: URL.createObjectURL(file) });
        setError(null);
        setIsScanning(true);
        setVisualDNA('');
        try {
            const dna = await geminiService.generateCharacterDNA(file);
            setVisualDNA(dna);
        } catch (e: any) {
            setError(e.message || 'Gagal memindai DNA karakter.');
        } finally {
            setIsScanning(false);
        }
    };
    
    const handleGenerateStory = async () => {
        if (!storyIdea.trim()) {
            setError('Ide cerita tidak boleh kosong.');
            return;
        }
        setIsStoryLoading(true);
        setError(null);
        setScenes([]);
        setGeneratedImages({});
        try {
            const scriptText = await geminiService.generateStoryScenes(storyIdea);
            const sceneBlocks = scriptText.split('---').filter(s => s.trim());
            const newScenes: Scene[] = sceneBlocks.map((block, index) => {
                const titleMatch = block.match(/\[JUDUL ADEGAN\](.*)/);
                const promptMatch = block.match(/\[PROMPT VISUAL\](.*)/s);
                return {
                    id: Date.now() + index,
                    title: titleMatch ? titleMatch[1].trim() : `Adegan ${index + 1}`,
                    visualPrompt: promptMatch ? promptMatch[1].trim() : '',
                };
            });
            setScenes(newScenes);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setIsStoryLoading(false);
        }
    };
    
    const handleGenerateSceneImage = async (sceneId: number, visualPrompt: string) => {
        if (!characterRef) {
            setError('Silakan upload referensi karakter di Langkah 1 terlebih dahulu.');
            return;
        }
        setIsImageLoading(prev => ({ ...prev, [sceneId]: true }));
        setError(null);
        
        const artStyleDetails = ART_STYLES.find(s => s.id === artStyle)?.description || '';
        const apiRatio = ratio === 'Square' ? '1:1' : ratio === 'Landscape' ? '16:9' : '9:16';
        
        const masterPrompt = `
            Art Style: ${artStyle}, ${artStyleDetails}.
            Sebuah adegan dari sebuah animasi.
            Nama Karakter: ${characterName}.
            Deskripsi Karakter (DNA Visual): ${visualDNA}.
            Pakaian Karakter: ${topClothing}, ${bottomClothing}.
            Deskripsi Adegan: ${visualPrompt}.
            Tampilan karakter HARUS konsisten dengan gambar referensi yang diberikan.
        `;

        try {
            const generatedImage = await geminiService.generateProductImage(
                masterPrompt,
                characterRef.file,
                apiRatio
            );
            setGeneratedImages(prev => ({ ...prev, [sceneId]: generatedImage }));
        } catch (e: any) {
            setError(e.message || 'Gagal membuat gambar adegan.');
        } finally {
            setIsImageLoading(prev => ({ ...prev, [sceneId]: false }));
        }
    };
    
    const handleSceneUpdate = (sceneId: number, field: 'title' | 'visualPrompt', value: string) => {
        setScenes(scenes.map(s => s.id === sceneId ? { ...s, [field]: value } : s));
    };

    const handleAddScene = () => {
        const newScene: Scene = {
            id: Date.now(),
            title: `Adegan ${scenes.length + 1}`,
            visualPrompt: '',
        };
        setScenes(prev => [...prev, newScene]);
    };

    const handleDeleteScene = (sceneId: number) => {
        setScenes(prev => prev.filter(s => s.id !== sceneId));
        setGeneratedImages(prev => {
            const newImages = { ...prev };
            delete newImages[sceneId];
            return newImages;
        });
    };

    return (
        <>
        <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
        <div className="container mx-auto max-w-4xl p-4 sm:p-6 lg:p-8">
            <header className="text-center mb-8">
                <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-wide flex items-center justify-center gap-3">
                    <AnimationIcon className="w-8 h-8 text-yellow-400" />
                    Animation Scene Generator
                </h1>
                <p className="text-gray-400 mt-2 text-sm sm:text-base">
                    Ubah ide cerita menjadi adegan visual dengan karakter yang konsisten.
                </p>
            </header>

            <main className="space-y-6">
                {/* --- Step 1: Character Blueprint --- */}
                <StepHeader number={1} title="Kunci Karakter (Blueprint)">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <div className="flex-shrink-0 w-28 h-28 rounded-lg bg-gray-700 flex items-center justify-center border-2 border-dashed border-gray-600">
                             {characterRef ? (
                                <img src={characterRef.previewUrl} alt="Referensi Karakter" className="w-full h-full object-cover rounded-lg" />
                            ) : (
                                <UserIcon className="w-12 h-12 text-gray-500" />
                            )}
                        </div>
                        <div className="flex-grow text-center sm:text-left">
                             <h4 className="font-bold text-white">Upload Referensi Karakter</h4>
                            <p className="text-xs text-gray-400 mt-1">Upload foto untuk "Scan DNA" visual karakter Anda.</p>
                             <input type="file" accept="image/*" ref={fileInputRef} onChange={(e) => handleFileChange(e.target.files?.[0] || null)} className="hidden"/>
                            <button onClick={() => fileInputRef.current?.click()} disabled={isScanning} className="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-600 text-sm">
                                {isScanning ? <Spinner className="!w-4 !h-4" /> : <UploadIcon className="w-4 h-4" />}
                                {isScanning ? 'Memindai...' : 'Pilih Foto'}
                            </button>
                        </div>
                    </div>
                    <div>
                         <label className="flex items-center gap-2 text-sm font-semibold text-gray-300 mb-2">
                            <LockIcon className="w-4 h-4 text-yellow-400"/> Visual DNA (Wajah & Rambut) - Terkunci
                        </label>
                        <textarea value={visualDNA} onChange={e => setVisualDNA(e.target.value)} rows={2} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white" placeholder={isScanning ? 'Menganalisis gambar...' : 'Hasil scan DNA akan muncul di sini'}/>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <input type="text" value={characterName} onChange={e => setCharacterName(e.target.value)} placeholder="Nama Karakter" className="p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white" />
                        <input type="text" value={topClothing} onChange={e => setTopClothing(e.target.value)} placeholder="Pakaian Atas" className="p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white" />
                        <input type="text" value={bottomClothing} onChange={e => setBottomClothing(e.target.value)} placeholder="Pakaian Bawah" className="p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white" />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <select value={ratio} onChange={e => setRatio(e.target.value as Ratio)} className="custom-select w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm">
                            {RATIOS.map(r => <option key={r.id} value={r.id}>{r.label} ({r.sublabel})</option>)}
                        </select>
                         <select value={artStyle} onChange={e => setArtStyle(e.target.value as ArtStyle)} className="custom-select w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm">
                            {ART_STYLES.map(s => <option key={s.id} value={s.id}>{s.id}</option>)}
                        </select>
                    </div>
                </StepHeader>

                {/* --- Step 2: Story Generation --- */}
                <StepHeader number={2} title="Buat Naskah Cerita">
                     <textarea value={storyIdea} onChange={e => setStoryIdea(e.target.value)} placeholder="Masukkan ide cerita singkat di sini..." className="w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white" rows={2}/>
                     <button onClick={handleGenerateStory} disabled={isStoryLoading} className="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-600">
                        {isStoryLoading ? <Spinner className="!w-5 !h-5"/> : <WandIcon className="w-5 h-5"/>}
                        Buat Cerita Otomatis
                    </button>
                </StepHeader>

                {/* --- Step 3: Scene Generation --- */}
                {scenes.length > 0 && (
                    <StepHeader number={3} title="Generate Gambar per Adegan">
                        {error && <p className="text-center text-red-400 mb-4 bg-red-900/30 p-3 rounded-md">{error}</p>}
                        <div className="space-y-5">
                            {scenes.map(scene => (
                                <div key={scene.id} className="p-4 bg-gray-800 rounded-md border border-gray-700">
                                    <div className="flex justify-between items-center mb-2">
                                        <input 
                                            type="text"
                                            value={scene.title}
                                            onChange={e => handleSceneUpdate(scene.id, 'title', e.target.value)}
                                            className="font-bold text-purple-400 bg-transparent border-0 p-0 focus:ring-0 focus:bg-gray-700 rounded"
                                        />
                                        <button onClick={() => handleDeleteScene(scene.id)} className="p-1 text-gray-500 hover:text-red-400">
                                            <TrashIcon className="w-4 h-4"/>
                                        </button>
                                    </div>
                                    <div className="flex flex-col md:flex-row items-start gap-4 mt-2">
                                        <div className="w-full md:w-1/2">
                                            <label className="block text-xs font-semibold text-gray-400 mb-1">Prompt Visual (Bisa diedit)</label>
                                            <textarea 
                                                value={scene.visualPrompt}
                                                onChange={e => handleSceneUpdate(scene.id, 'visualPrompt', e.target.value)}
                                                rows={4} 
                                                className="w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm"
                                            />
                                        </div>
                                        <div className="w-full md:w-1/2">
                                            <div className="aspect-video w-full bg-black rounded-lg flex items-center justify-center relative group">
                                                {isImageLoading[scene.id] && <Spinner />}
                                                {!isImageLoading[scene.id] && generatedImages[scene.id] && (
                                                    <>
                                                        <img src={generatedImages[scene.id]} alt={`Adegan ${scene.title}`} className="w-full h-full object-cover rounded-lg"/>
                                                        <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                            <button onClick={() => setFullscreenImage(generatedImages[scene.id])} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Tampilan Penuh">
                                                                <ExpandIcon className="w-5 h-5" />
                                                            </button>
                                                            <a href={generatedImages[scene.id]} download={`scene-${scene.id}.png`} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Unduh">
                                                                <DownloadIcon className="w-5 h-5" />
                                                            </a>
                                                        </div>
                                                    </>
                                                )}
                                                {!isImageLoading[scene.id] && !generatedImages[scene.id] && (
                                                    <GalleryIcon className="w-10 h-10 text-gray-600"/>
                                                )}
                                            </div>
                                            <button onClick={() => handleGenerateSceneImage(scene.id, scene.visualPrompt)} disabled={isImageLoading[scene.id]} className="w-full mt-2 flex items-center justify-center gap-2 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors disabled:bg-gray-600 text-sm">
                                                {isImageLoading[scene.id] ? <Spinner className="!w-4 !h-4" /> : <PlusIcon className="w-4 h-4"/>}
                                                Generate Gambar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="pt-4">
                            <button onClick={handleAddScene} className="w-full flex items-center justify-center gap-2 py-2 border-2 border-dashed border-gray-600 text-gray-400 font-semibold rounded-lg hover:bg-gray-800 hover:border-gray-500 transition-colors">
                                <PlusIcon className="w-5 h-5"/>
                                Tambah Adegan
                            </button>
                        </div>
                    </StepHeader>
                )}
            </main>
        </div>
        </>
    );
};

export default BlueprintGenerator;