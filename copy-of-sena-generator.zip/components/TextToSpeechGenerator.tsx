import React, { useState, useEffect, useMemo } from 'react';
import { VOICES, GENDERS, STYLES } from '../data/voices';
import type { Voice, VoiceGender, VoiceStyle } from '../types';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';
import { InfoIcon } from './icons/InfoIcon';
import { SoundIcon } from './icons/SoundIcon';
// FIX: Import createWavUrl to correctly handle raw audio data.
import { createWavUrl } from '../utils/audio';

const TextToSpeechGenerator: React.FC = () => {
    const [genderFilter, setGenderFilter] = useState<VoiceGender | 'Semua'>('Semua');
    const [styleFilter, setStyleFilter] = useState<VoiceStyle | 'Semua'>('Semua');
    const [selectedVoice, setSelectedVoice] = useState<string>(VOICES[0].apiName);
    const [text, setText] = useState('Selamat datang! Mari kita dengarkan suara Kore yang tegas. Ingat, gunakan koma untuk jeda, dan tanda seru untuk penekanan!');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [audioResult, setAudioResult] = useState<string | null>(null);
    const MAX_CHARS = 500;

    const filteredVoices = useMemo(() => {
        return VOICES.filter(voice => {
            const genderMatch = genderFilter === 'Semua' || voice.gender === genderFilter;
            const styleMatch = styleFilter === 'Semua' || voice.styles.includes(styleFilter);
            return genderMatch && styleMatch;
        });
    }, [genderFilter, styleFilter]);

    useEffect(() => {
        if (filteredVoices.length > 0) {
            const isCurrentSelectionValid = filteredVoices.some(v => v.apiName === selectedVoice);
            if (!isCurrentSelectionValid) {
                setSelectedVoice(filteredVoices[0].apiName);
            }
        }
    }, [filteredVoices, selectedVoice]);

    const handleGenerate = async () => {
        if (!text.trim()) {
            setError('Teks tidak boleh kosong.');
            return;
        }
        if (!selectedVoice) {
            setError('Silakan pilih suara terlebih dahulu.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setAudioResult(null);

        try {
            const audioData = await geminiService.generateTextToSpeech(text, selectedVoice);
            // FIX: Convert raw PCM audio data to a playable WAV blob URL.
            setAudioResult(createWavUrl(audioData));
        } catch (e: any) {
            setError(e.message || 'Terjadi kesalahan tak terduga.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const renderFilterButtons = (
        items: readonly ('Semua' | VoiceGender | VoiceStyle)[], 
        selected: 'Semua' | VoiceGender | VoiceStyle, 
        setter: React.Dispatch<React.SetStateAction<any>>
    ) => (
        <div className="flex flex-wrap gap-2">
            {items.map(item => (
                <button
                    key={item}
                    onClick={() => setter(item)}
                    className={`px-4 py-1.5 text-sm rounded-full transition-colors duration-200 ${
                        selected === item
                            ? 'bg-purple-600 text-white font-semibold'
                            : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    }`}
                >
                    {item}
                </button>
            ))}
        </div>
    );

    return (
        <div className="container mx-auto max-w-4xl p-4 sm:p-6 lg:p-8">
            <div className="bg-gray-800 p-6 sm:p-8 rounded-xl shadow-lg space-y-6">
                <div className="flex items-center gap-3">
                    <SoundIcon className="w-8 h-8 text-purple-500" />
                    <h1 className="text-2xl sm:text-3xl font-bold text-white">Generator Teks-ke-Suara (Gemini TTS)</h1>
                </div>

                <div className="bg-blue-900/50 border-l-4 border-blue-500 text-blue-200 p-4 rounded-md" role="alert">
                    <div className="flex">
                        <InfoIcon className="w-5 h-5 mt-0.5" />
                        <div className="ml-3">
                            <p className="font-bold">Tips: Kontrol Suara (Nada, Intonasi, Tempo):</p>
                            <ul className="list-disc list-inside text-sm mt-1">
                                <li>Karakteristik teknis dikontrol melalui teks Anda (tanda baca, pemilihan kata) dan karakteristik bawaan dari setiap suara.</li>
                                <li>Gunakan koma (,) untuk jeda singkat dan tanda seru (!) untuk penekanan.</li>
                            </ul>
                        </div>
                    </div>
                </div>

                {/* Filters */}
                <div className="space-y-4">
                    <div>
                        <label className="block text-base font-semibold text-gray-300 mb-2">Gender:</label>
                        {renderFilterButtons(['Semua', ...GENDERS], genderFilter, setGenderFilter)}
                    </div>
                    <div>
                        <label className="block text-base font-semibold text-gray-300 mb-2">Karakter berdasarkan Gaya dan Kepribadian:</label>
                        {renderFilterButtons(['Semua', ...STYLES], styleFilter, setStyleFilter)}
                    </div>
                </div>

                {/* Voice Selection */}
                <div>
                    <label htmlFor="voice-select" className="block text-base font-semibold text-gray-300 mb-2">Pilihan Suara yang Tersedia (Hasil Filter):</label>
                    <select
                        id="voice-select"
                        value={selectedVoice}
                        onChange={(e) => setSelectedVoice(e.target.value)}
                        className="custom-select w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        disabled={filteredVoices.length === 0}
                    >
                        {filteredVoices.length > 0 ? (
                            filteredVoices.map(voice => (
                                <option key={voice.apiName} value={voice.apiName}>
                                    {voice.name} - {voice.gender} ({voice.description})
                                </option>
                            ))
                        ) : (
                            <option>Tidak ada suara yang cocok dengan filter</option>
                        )}
                    </select>
                </div>

                {/* Text Input */}
                <div>
                    <label htmlFor="tts-text" className="block text-base font-semibold text-gray-300 mb-2">Teks untuk diubah menjadi Suara:</label>
                    <div className="relative">
                        <textarea
                            id="tts-text"
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                            maxLength={MAX_CHARS}
                            className="w-full p-3 pr-20 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 resize-none text-white"
                            rows={5}
                            placeholder="Masukkan teks di sini..."
                        />
                        <div className="absolute bottom-2 right-3 text-sm text-gray-500">
                            {text.length}/{MAX_CHARS} Karakter
                        </div>
                    </div>
                </div>

                {/* Result and Generate Button */}
                {error && <p className="text-red-300 bg-red-900/50 p-3 rounded-md">{error}</p>}
                
                {audioResult && (
                    <div className="animate-fadeInDown">
                        <label className="block text-base font-semibold text-gray-300 mb-2">Hasil Audio:</label>
                        <audio controls src={audioResult} className="w-full">
                            Your browser does not support the audio element.
                        </audio>
                    </div>
                )}
                
                <button
                    onClick={handleGenerate}
                    disabled={isLoading}
                    className="w-full flex items-center justify-center px-6 py-4 bg-purple-600 text-white rounded-lg text-lg font-semibold hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? <Spinner className="!w-6 !h-6" /> : 'Buat Voice Over'}
                </button>
            </div>
        </div>
    );
};

export default TextToSpeechGenerator;