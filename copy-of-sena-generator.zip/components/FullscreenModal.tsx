
import React from 'react';

interface FullscreenModalProps {
    imageUrl: string | null;
    onClose: () => void;
}

const FullscreenModal: React.FC<FullscreenModalProps> = ({ imageUrl, onClose }) => {
    if (!imageUrl) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 animate-fadeInDown"
            onClick={onClose}
        >
            <button 
                onClick={onClose} 
                className="absolute top-4 right-4 text-white bg-white/20 hover:bg-white/30 rounded-full p-2"
                aria-label="Close fullscreen view"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
                </svg>
            </button>
            <img 
                src={imageUrl} 
                alt="Fullscreen generated content" 
                className="max-w-[95vw] max-h-[95vh] object-contain"
                onClick={(e) => e.stopPropagation()} // Prevent closing when clicking on the image
            />
        </div>
    );
};

export default FullscreenModal;