import React, { useState } from 'react';
import Spinner from './Spinner';
import * as geminiService from '../services/geminiService';
import { GalleryIcon } from './icons/GalleryIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import FullscreenModal from './FullscreenModal';
import { LockIcon } from './icons/LockIcon';
import { UserIcon } from './icons/UserIcon';
import { CheckIcon } from './icons/CheckIcon';

type Ratio = '3:4' | '1:1' | '16:9' | '9:16';
const RATIOS: Ratio[] = ['3:4', '1:1', '16:9', '9:16'];

type ArtStyle = '3D Animation Style' | 'Japanese Anime Style' | 'Style Anime' | 'Cartoon Style' | 'Realistic Fantasy';
const ART_STYLES: ArtStyle[] = ['3D Animation Style', 'Japanese Anime Style', 'Style Anime', 'Cartoon Style', 'Realistic Fantasy'];

const base64ToFile = (dataUrl: string, filename: string): File => {
    const [header, data] = dataUrl.split(',');
    const mime = header.match(/:(.*?);/)?.[1] || 'image/png';
    const bstr = atob(data);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
};

const CharacterCreator: React.FC = () => {
    // Inputs
    const [name, setName] = useState('Budi');
    const [characterDescription, setCharacterDescription] = useState('Remaja laki-laki dengan rambut hitam pendek dan senyum ramah, mengenakan kaos merah polos dan celana jeans biru, dalam pose berdiri santai menghadap kamera.');
    const [ratio, setRatio] = useState<Ratio>('3:4');
    const [artStyle, setArtStyle] = useState<ArtStyle>('3D Animation Style');

    // Main Character State
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [mainImage, setMainImage] = useState<string | null>(null);
    const [mainImageFile, setMainImageFile] = useState<File | null>(null);

    // DNA State
    const [visualDNA, setVisualDNA] = useState<string | null>(null);
    const [isScanningDNA, setIsScanningDNA] = useState(false);

    // Expressions State
    const [isGeneratingExpressions, setIsGeneratingExpressions] = useState(false);
    const [expressionImages, setExpressionImages] = useState<Record<string, string>>({});

    // Other UI State
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
    const EXPRESSIONS = ['Happy', 'Sad', 'Angry', 'Surprised'];

    const resetResults = () => {
        setMainImage(null);
        setMainImageFile(null);
        setVisualDNA(null);
        setIsScanningDNA(false);
        setExpressionImages({});
        setIsGeneratingExpressions(false);
    };

    const handleGenerateMainCharacter = async () => {
        if (!name.trim() || !characterDescription.trim()) {
            setError('Nama dan deskripsi karakter harus diisi.');
            return;
        }

        setIsLoading(true);
        setError(null);
        resetResults();
        
        const fullPrompt = `full body character concept art, ${name}, ${characterDescription}, ${artStyle}, clean white background, high detail`;

        try {
            const generatedImageB64 = await geminiService.generateImage(fullPrompt, 'gemini-2.5-flash-image', ratio);
            setMainImage(generatedImageB64);

            const imageFile = base64ToFile(generatedImageB64, 'character.png');
            setMainImageFile(imageFile);

            setIsScanningDNA(true);
            const dna = await geminiService.generateCharacterDNA(imageFile);
            setVisualDNA(dna);
        } catch (e: any) {
            setError(e.message || 'Terjadi kesalahan tak terduga.');
        } finally {
            setIsLoading(false);
            setIsScanningDNA(false);
        }
    };
    
    const handleGenerateExpressions = async () => {
        if (!mainImageFile || !visualDNA) {
            setError("Karakter utama dan DNA harus ada sebelum membuat ekspresi.");
            return;
        }
        setIsGeneratingExpressions(true);
        setError(null);

        const promises = EXPRESSIONS.map(expression => {
            const expressionPrompt = `
                Art Style: ${artStyle}.
                Headshot of a character with these features: ${visualDNA}.
                The character has a ${expression.toLowerCase()} expression.
                The character's appearance MUST be consistent with the reference image.
                Clean white background.
            `;
            return geminiService.generateProductImage(expressionPrompt, mainImageFile, '1:1');
        });

        try {
            const results = await Promise.all(promises);
            const newExpressionImages = EXPRESSIONS.reduce((acc, expression, index) => {
                acc[expression] = results[index];
                return acc;
            }, {} as Record<string, string>);
            setExpressionImages(newExpressionImages);
        } catch (e: any) {
            setError(e.message || 'Gagal membuat satu atau lebih gambar ekspresi.');
        } finally {
            setIsGeneratingExpressions(false);
        }
    };
    
    const Section: React.FC<{ icon: React.ReactNode, title: string, children: React.ReactNode }> = ({ icon, title, children }) => (
        <div className="bg-gray-900 rounded-lg p-5 border border-gray-800">
            <div className="flex items-center gap-3 mb-4">
                {icon}
                <h2 className="text-lg font-bold text-white">{title}</h2>
            </div>
            <div className="space-y-4">{children}</div>
        </div>
    );
    
    const LabeledInput: React.FC<{ label: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, placeholder?: string }> = ({ label, value, onChange, placeholder }) => (
        <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">{label}</label>
            <input type="text" value={value} onChange={onChange} placeholder={placeholder} className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg focus:ring-1 focus:ring-purple-500 text-white text-sm" />
        </div>
    );

    const LabeledTextarea: React.FC<{ label: string, value: string, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void, placeholder?: string, rows?: number }> = ({ label, value, onChange, placeholder, rows = 2 }) => (
        <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">{label}</label>
            <textarea value={value} onChange={onChange} placeholder={placeholder} rows={rows} className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg focus:ring-1 focus:ring-purple-500 text-white text-sm resize-y" />
        </div>
    );
    
    return (
        <>
            <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
            <div className="container mx-auto max-w-4xl p-4 sm:p-6 lg:p-8 space-y-6">
                <header className="text-center">
                    <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-wide flex items-center justify-center gap-3">
                        <UserIcon className="w-8 h-8 text-teal-400" />
                        Character Creator
                    </h1>
                    <p className="text-gray-400 mt-2">Buat karakter dan hasilkan lembar ekspresi untuk animasi.</p>
                </header>

                <Section icon={<SparklesIcon className="w-6 h-6 text-teal-400" />} title="1. Deskripsi Karakter">
                    <LabeledInput 
                        label="Nama Karakter" 
                        value={name} 
                        onChange={e => setName(e.target.value)} 
                        placeholder="Contoh: Budi"
                    />
                    <LabeledTextarea 
                        label="Deskripsi Keseluruhan (Penampilan, Pakaian, Pose)" 
                        value={characterDescription} 
                        onChange={e => setCharacterDescription(e.target.value)} 
                        rows={6}
                        placeholder="Contoh: Remaja laki-laki dengan rambut hitam pendek dan senyum ramah, mengenakan kaos merah polos dan celana jeans biru, dalam pose berdiri santai menghadap kamera."
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                        <div>
                            <label className="block text-sm font-medium text-gray-400 mb-2">Gaya Seni</label>
                            <select value={artStyle} onChange={e => setArtStyle(e.target.value as ArtStyle)} className="custom-select w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg">
                                {ART_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-400 mb-2">Rasio</label>
                            <select value={ratio} onChange={e => setRatio(e.target.value as Ratio)} className="custom-select w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg">
                                {RATIOS.map(r => <option key={r} value={r}>{r}</option>)}
                            </select>
                        </div>
                    </div>
                     <button
                        onClick={handleGenerateMainCharacter}
                        disabled={isLoading}
                        className="w-full flex items-center justify-center gap-2 py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg transition-colors disabled:bg-gray-600"
                    >
                        {isLoading ? <Spinner className="!w-6 !h-6" /> : <SparklesIcon className="w-6 h-6" />}
                        Generate Karakter Utama
                    </button>
                    {error && <p className="text-sm text-red-400 text-center mt-2">{error}</p>}
                </Section>
                
                {(isLoading || mainImage) && (
                    <Section icon={<CheckIcon className="w-6 h-6 text-green-400" />} title="2. Hasil & DNA Visual">
                        <div className="flex justify-center p-2 bg-black rounded-md min-h-[300px] items-center">
                            {isLoading ? <Spinner className="!w-12 !h-12" /> : mainImage && (
                                <div className="relative group animate-fadeInDown">
                                    <img src={mainImage} alt="Karakter yang dihasilkan" className="max-h-[400px] object-contain rounded"/>
                                     <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button onClick={() => setFullscreenImage(mainImage)} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Tampilan Penuh">
                                            <ExpandIcon className="w-5 h-5" />
                                        </button>
                                        <a href={mainImage} download="main-character.png" className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Unduh">
                                            <DownloadIcon className="w-5 h-5" />
                                        </a>
                                    </div>
                                </div>
                            )}
                        </div>
                        
                        {(isScanningDNA || visualDNA) && (
                            <div>
                                <label className="flex items-center gap-2 text-sm font-semibold text-gray-300 mb-2">
                                    <LockIcon className="w-4 h-4 text-yellow-400"/> Visual DNA (Terkunci)
                                </label>
                                <textarea readOnly value={visualDNA || ''} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm" placeholder="Memindai DNA dari gambar..." rows={2}/>
                            </div>
                        )}
                    </Section>
                )}

                {visualDNA && (
                    <Section icon={<GalleryIcon className="w-6 h-6 text-purple-400" />} title="3. Buat Lembar Karakter">
                        <p className="text-sm text-gray-400">Gunakan DNA visual yang terkunci untuk menghasilkan berbagai ekspresi dengan gaya dan wajah yang konsisten.</p>
                        <button
                            onClick={handleGenerateExpressions}
                            disabled={isGeneratingExpressions}
                            className="w-full flex items-center justify-center gap-2 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg transition-colors disabled:bg-gray-600"
                        >
                            {isGeneratingExpressions ? <Spinner className="!w-6 !h-6" /> : <SparklesIcon className="w-6 h-6" />}
                            Generate Expressions
                        </button>
                        
                        {isGeneratingExpressions && <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">{EXPRESSIONS.map(exp => <div key={exp} className="aspect-square bg-gray-800 rounded-lg flex flex-col items-center justify-center"><Spinner /><p className="text-xs mt-2">{exp}</p></div>)}</div>}

                        {Object.keys(expressionImages).length > 0 && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 animate-fadeInDown">
                                {EXPRESSIONS.map(expression => (
                                    <div key={expression} className="text-center">
                                        <div className="relative group aspect-square">
                                            <img src={expressionImages[expression]} alt={expression} className="w-full h-full object-cover rounded-lg"/>
                                            <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                 <button onClick={() => setFullscreenImage(expressionImages[expression])} className="p-1.5 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Tampilan Penuh">
                                                    <ExpandIcon className="w-4 h-4" />
                                                </button>
                                                <a href={expressionImages[expression]} download={`expression-${expression.toLowerCase()}.png`} className="p-1.5 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Unduh">
                                                    <DownloadIcon className="w-4 h-4" />
                                                </a>
                                            </div>
                                        </div>
                                        <p className="text-sm font-semibold mt-2">{expression}</p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </Section>
                )}
            </div>
        </>
    );
};

export default CharacterCreator;