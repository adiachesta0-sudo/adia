import React, { useState, useRef } from 'react';
import Spinner from './Spinner';
import * as geminiService from '../services/geminiService';
import { LightningIcon } from './icons/LightningIcon';
import { CameraIcon } from './icons/CameraIcon';
import { UploadIcon } from './icons/UploadIcon';
import { TextIcon } from './icons/TextIcon';
import { UserIcon } from './icons/UserIcon';
import { SettingsIcon } from './icons/SettingsIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import FullscreenModal from './FullscreenModal';
import { VideoIcon } from './icons/VideoIcon';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';
import { WandIcon } from './icons/WandIcon';
import { LockIcon } from './icons/LockIcon';


interface FilePreview {
    file: File;
    previewUrl: string;
}

interface GeneratedTheme {
    theme: string;
    images: string[];
}


const AffiliateContentGenerator: React.FC = () => {
    const [mainProductPhoto, setMainProductPhoto] = useState<FilePreview | null>(null);
    const [supportingPhoto, setSupportingPhoto] = useState<FilePreview | null>(null);
    const [modelPhoto, setModelPhoto] = useState<FilePreview | null>(null);
    const [backgroundImage, setBackgroundImage] = useState<FilePreview | null>(null);

    const [description, setDescription] = useState('');
    const [modelClothing, setModelClothing] = useState('');
    const [modelPose, setModelPose] = useState('');
    
    const [ratio, setRatio] = useState('9:16');
    const [language, setLanguage] = useState('Indonesia');
    const [storeName, setStoreName] = useState('');
    const [accent, setAccent] = useState('');
    
    const [isLoading, setIsLoading] = useState(false);
    const [isPoseLoading, setIsPoseLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [generatedThemes, setGeneratedThemes] = useState<GeneratedTheme[]>([]);
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
    const [videoPrompt, setVideoPrompt] = useState<string | null>(null);
    const [showVideoPrompt, setShowVideoPrompt] = useState(true);
    const [isVideoPromptCopied, setIsVideoPromptCopied] = useState(false);
    
    const mainPhotoRef = useRef<HTMLInputElement>(null);
    const supportingPhotoRef = useRef<HTMLInputElement>(null);
    const modelPhotoRef = useRef<HTMLInputElement>(null);
    const backgroundPhotoRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (file: File | null, setter: React.Dispatch<React.SetStateAction<FilePreview | null>>) => {
        if (file) {
            setter({ file, previewUrl: URL.createObjectURL(file) });
        }
    };

    const handleGenerate = async () => {
        if (!mainProductPhoto) {
            setError('FOTO PRODUK UTAMA (WAJIB) tidak boleh kosong.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setGeneratedThemes([]);
        setVideoPrompt(null);
        setIsVideoPromptCopied(false);
        setStatusMessage('Memulai proses...');

        try {
            const onBatchComplete = (batchResults: { theme: string, imageUrl: string }[]) => {
                setGeneratedThemes(prevThemes => {
                    const themesMap = new Map<string, string[]>();
                    
                    // Populate map with existing themes
                    prevThemes.forEach(theme => {
                        themesMap.set(theme.theme, theme.images);
                    });

                    // Add new results from the batch
                    batchResults.forEach(result => {
                        if (!themesMap.has(result.theme)) {
                            themesMap.set(result.theme, []);
                        }
                        themesMap.get(result.theme)!.push(result.imageUrl);
                    });

                    // Convert map back to array
                    return Array.from(themesMap, ([theme, images]) => ({ theme, images }));
                });
            };

            const onDnaComplete = (dna: string) => {
                 setStatusMessage('DNA Visual model berhasil dipindai. Memulai pembuatan gambar...');
            };

            await geminiService.generateAffiliateContent({
                mainProductPhoto: mainProductPhoto.file,
                supportingPhoto: supportingPhoto?.file,
                modelPhoto: modelPhoto?.file,
                backgroundImage: backgroundImage?.file,
                description,
                modelClothing,
                modelPose,
                ratio,
                language,
                storeName,
                accent
            }, onBatchComplete, onDnaComplete, setStatusMessage);

            if (description) {
                const vp = await geminiService.generateVideoPromptFromText(description);
                setVideoPrompt(vp);
            }
        } catch (e: any) {
            setError(e.message || 'Terjadi kesalahan tak terduga.');
        } finally {
            setIsLoading(false);
            setStatusMessage('Selesai! 80 foto berhasil dibuat.');
        }
    };

    const handleGeneratePose = async () => {
        if (!mainProductPhoto) {
            setError('Upload FOTO PRODUK UTAMA terlebih dahulu untuk membuat ide pose.');
            return;
        }
        if (!description.trim()) {
            setError('Isi DESKRIPSI & DETAIL terlebih dahulu untuk membuat ide pose.');
            return;
        }

        setIsPoseLoading(true);
        setError(null);
        try {
            const poseIdea = await geminiService.generateModelPosePrompt(description, mainProductPhoto.file);
            setModelPose(poseIdea);
        } catch (e: any) {
            setError(e.message || 'Gagal membuat ide pose.');
        } finally {
            setIsPoseLoading(false);
        }
    };

     const handleCopyVideoPrompt = () => {
        if (videoPrompt) {
            navigator.clipboard.writeText(videoPrompt);
            setIsVideoPromptCopied(true);
            setTimeout(() => setIsVideoPromptCopied(false), 2000);
        }
    };

    const FileUploadBox = ({ file, onClick, label, isOptional = false }: { file: FilePreview | null, onClick: () => void, label: string, isOptional?: boolean }) => (
        <div>
            <p className="text-xs text-gray-400 mb-1">{label}</p>
            <div onClick={onClick} className={`cursor-pointer aspect-square w-full bg-black border-2 border-dashed border-gray-700 rounded-md flex items-center justify-center text-center text-gray-500 hover:border-gray-500 hover:bg-gray-900 transition-colors ${!isOptional && error && !file ? 'border-red-500' : ''}`}>
                {file ? (
                    <img src={file.previewUrl} alt="Preview" className="w-full h-full object-cover rounded-md" />
                ) : (
                    <div className="flex flex-col items-center">
                        <UploadIcon className="w-6 h-6 mb-1" />
                        <span className="text-xs">UPLOAD FOTO</span>
                    </div>
                )}
            </div>
        </div>
    );
    
    const totalGeneratedImages = generatedThemes.reduce((acc, theme) => acc + theme.images.length, 0);

    return (
        <>
            <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
            <div className="bg-black text-gray-300 min-h-full font-sans p-4 sm:p-6 lg:p-8">
                <header className="text-center mb-8 border-b border-gray-800 pb-4">
                    <h1 className="text-3xl font-bold text-white tracking-wider flex items-center justify-center gap-3">
                        <LightningIcon className="w-7 h-7"/> AFFILIATE CONTENT GENERATOR
                    </h1>
                    <p className="text-xs text-gray-500 tracking-widest mt-1">MONOCHROME EDITION V5.1 • POWERED BY GEMINI</p>
                </header>

                <div className="flex flex-col md:flex-row gap-8">
                    {/* Left Control Panel */}
                    <div className="w-full md:w-[350px] flex-shrink-0 space-y-4">
                        <div className="p-4 bg-[#1C1C1C] rounded-lg space-y-3">
                            <h3 className="font-semibold flex items-center gap-2"><CameraIcon className="w-5 h-5"/> 1. PRODUK & FOTO</h3>
                            <FileUploadBox file={mainProductPhoto} onClick={() => mainPhotoRef.current?.click()} label="FOTO PRODUK UTAMA (WAJIB)" />
                            <input type="file" accept="image/*" ref={mainPhotoRef} onChange={e => handleFileChange(e.target.files?.[0] || null, setMainProductPhoto)} className="hidden" />
                            
                            <FileUploadBox file={supportingPhoto} onClick={() => supportingPhotoRef.current?.click()} label="FOTO PENDUKUNG (OPSIONAL)" isOptional />
                            <input type="file" accept="image/*" ref={supportingPhotoRef} onChange={e => handleFileChange(e.target.files?.[0] || null, setSupportingPhoto)} className="hidden" />
                        </div>

                        <div className="p-4 bg-[#1C1C1C] rounded-lg space-y-2">
                            <h3 className="font-semibold flex items-center gap-2"><TextIcon className="w-5 h-5"/> 2. DESKRIPSI & DETAIL</h3>
                            <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Jelaskan produk dan suasana yang diinginkan..." className="w-full bg-black border border-gray-700 rounded-md p-2 text-sm h-24 resize-none text-white" />
                        </div>

                        <div className="p-4 bg-[#1C1C1C] rounded-lg space-y-3">
                            <h3 className="font-semibold flex items-center gap-2"><UserIcon className="w-5 h-5"/> 3. MODEL & GAYA</h3>
                            <FileUploadBox file={modelPhoto} onClick={() => modelPhotoRef.current?.click()} label="WAJAH MODEL (OPSIONAL)" isOptional/>
                            <input type="file" accept="image/*" ref={modelPhotoRef} onChange={e => handleFileChange(e.target.files?.[0] || null, setModelPhoto)} className="hidden" />
                             <FileUploadBox file={backgroundImage} onClick={() => backgroundPhotoRef.current?.click()} label="LATAR BELAKANG (OPSIONAL)" isOptional/>
                            <input type="file" accept="image/*" ref={backgroundPhotoRef} onChange={e => handleFileChange(e.target.files?.[0] || null, setBackgroundImage)} className="hidden" />
                            <input type="text" value={modelClothing} onChange={e => setModelClothing(e.target.value)} placeholder="Pakaian Model (Cth: Kaos Polos Hitam)" className="w-full bg-black border border-gray-700 rounded-md p-2 text-sm text-white" />
                             <div className="relative">
                                <input 
                                    type="text" 
                                    value={modelPose} 
                                    onChange={e => setModelPose(e.target.value)} 
                                    placeholder="Pose (Cth: Memegang produk di sebelah pipi)" 
                                    className="w-full bg-black border border-gray-700 rounded-md p-2 text-sm text-white pr-10" 
                                />
                                <button 
                                    onClick={handleGeneratePose} 
                                    disabled={isPoseLoading}
                                    className="absolute top-1/2 right-2 -translate-y-1/2 p-1 text-gray-400 hover:text-purple-400 transition-colors disabled:cursor-not-allowed"
                                    title="Buat ide pose otomatis"
                                >
                                    {isPoseLoading ? <Spinner className="!w-5 !h-5" /> : <WandIcon className="w-5 h-5" />}
                                </button>
                            </div>
                        </div>

                        <div className="p-4 bg-[#1C1C1C] rounded-lg space-y-3">
                            <h3 className="font-semibold flex items-center gap-2"><SettingsIcon className="w-5 h-5"/> 4. PENGATURAN</h3>
                            <div className="grid grid-cols-2 gap-2">
                                <select value={ratio} onChange={e => setRatio(e.target.value)} className="custom-select w-full bg-black border border-gray-700 rounded-md p-2 text-sm text-white">
                                    <option value="9:16">9:16 (Story/Reels)</option>
                                    <option value="1:1">1:1 (Square)</option>
                                    <option value="16:9">16:9 (Landscape)</option>
                                    <option value="3:4">3:4 (Portrait)</option>
                                </select>
                                <select value={language} onChange={e => setLanguage(e.target.value)} className="custom-select w-full bg-black border border-gray-700 rounded-md p-2 text-sm text-white">
                                    <option>Indonesia</option>
                                    <option>English</option>
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                <input type="text" value={storeName} onChange={e => setStoreName(e.target.value)} placeholder="Nama Toko (Signage)" className="w-full bg-black border border-gray-700 rounded-md p-2 text-sm text-white" />
                                <input type="text" value={accent} onChange={e => setAccent(e.target.value)} placeholder="Aksen (Jawa/Jaksel)" className="w-full bg-black border border-gray-700 rounded-md p-2 text-sm text-white" />
                            </div>
                        </div>

                        <button onClick={handleGenerate} disabled={isLoading} className="w-full p-3 bg-white text-black font-bold rounded-md hover:bg-gray-300 transition-colors disabled:bg-gray-500 disabled:text-gray-700">
                            {isLoading ? <Spinner className="!border-black mx-auto !w-6 !h-6" /> : 'GENERATE 80 FOTO KONTEN'}
                        </button>
                        {error && <p className="text-sm text-red-400 text-center mt-2">{error}</p>}
                    </div>
                    {/* Right Gallery */}
                    <div className="flex-1 min-h-[80vh]">
                        {(isLoading || generatedThemes.length > 0) ? (
                            <div className="space-y-6 animate-fadeInDown">
                                <h2 className="text-2xl font-bold tracking-widest flex items-center gap-3">
                                    HASIL GENERATE 
                                    <span className="text-gray-600">({totalGeneratedImages} / 80)</span>
                                    {isLoading && <Spinner className="!w-5 !h-5" />}
                                </h2>
                                {statusMessage && <p className="text-sm text-purple-400 flex items-center gap-2"><LockIcon className="w-4 h-4"/> {statusMessage}</p>}
                                
                                <div className="space-y-6 max-h-[80vh] overflow-y-auto pr-2">
                                    {generatedThemes.map((theme, themeIndex) => (
                                        <div key={themeIndex} className="animate-fadeInDown">
                                            <h3 className="font-semibold text-lg text-purple-300 mb-2 border-b border-gray-800 pb-1">{theme.theme}</h3>
                                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                                {theme.images.map((imageUrl, imgIndex) => (
                                                     <div key={imgIndex} className="relative group">
                                                        <img src={imageUrl} alt={`Konten ${theme.theme} ${imgIndex + 1}`} className="rounded-lg w-full" />
                                                        <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                            <button onClick={() => setFullscreenImage(imageUrl)} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white">
                                                                <ExpandIcon className="w-5 h-5" />
                                                            </button>
                                                            <a href={imageUrl} download={`affiliate-content-${theme.theme}-${imgIndex + 1}.png`} className="p-2 bg-black/50 hover:bg-black/80 rounded-full text-white">
                                                                <DownloadIcon className="w-5 h-5" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                    {isLoading && <div className="text-center py-10"><Spinner className="mx-auto !w-10 !h-10"/></div>}
                                </div>

                                {videoPrompt && !isLoading && (
                                <div className="mt-8 p-4 bg-[#1C1C1C] rounded-lg">
                                    <button onClick={() => setShowVideoPrompt(prev => !prev)} className="w-full flex items-center justify-between text-left font-semibold text-lg text-white">
                                        <span className="flex items-center gap-2"><VideoIcon className="w-5 h-5 text-purple-400"/>Prompt Video Promosi</span>
                                        <span className={`transform transition-transform ${showVideoPrompt ? 'rotate-180' : ''}`}>&#9660;</span>
                                    </button>
                                    {showVideoPrompt && (
                                        <div className="mt-4 pt-4 border-t border-gray-700 space-y-2 animate-fadeInDown">
                                            <p className="text-sm text-gray-400 italic whitespace-pre-wrap">{videoPrompt}</p>
                                            <button onClick={handleCopyVideoPrompt} className="w-full flex items-center justify-center gap-1.5 py-2 mt-2 bg-gray-700 hover:bg-gray-600 text-white text-xs font-semibold rounded-md transition-colors">
                                                {isVideoPromptCopied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <ClipboardIcon className="w-4 h-4" />}
                                                {isVideoPromptCopied ? 'Tersalin!' : 'Salin Prompt Video'}
                                            </button>
                                        </div>
                                    )}
                                </div>
                                )}
                            </div>
                        ) : (
                             <div className="space-y-4">
                                <h2 className="text-2xl font-bold tracking-widest">GALERI HASIL</h2>
                                <div className="grid grid-cols-2 gap-4">
                                    {Array(8).fill(0).map((_, index) => (
                                        <div key={index} className={`aspect-[${ratio.replace(':', '/')}] bg-gray-900 border-2 border-dashed border-gray-800 rounded-lg flex items-center justify-center`}>
                                            <CameraIcon className="w-12 h-12 text-gray-700" />
                                        </div>
                                    ))}
                                </div>
                                <p className="text-center text-gray-500 mt-4">80 variasi konten Anda akan muncul di sini dalam 20 tema berbeda.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

export default AffiliateContentGenerator;