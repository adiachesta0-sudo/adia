import React, { useState, useRef } from 'react';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';
import { FilmSlateIcon } from './icons/FilmSlateIcon';
import { WandIcon } from './icons/WandIcon';
import { UploadIcon } from './icons/UploadIcon';
import { TrashIcon } from './icons/TrashIcon';
import { LockIcon } from './icons/LockIcon';
import { GalleryIcon } from './icons/GalleryIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ExpandIcon } from './icons/ExpandIcon';
import FullscreenModal from './FullscreenModal';
import { ImageIcon } from './icons/ImageIcon';
import { PlusIcon } from './icons/PlusIcon';

interface FilePreview {
    file: File;
    previewUrl: string;
}

interface Scene {
    id: number;
    title: string;
    script: string; // Voiceover
    visualPrompt: string; // Prompt for image generation
}

type ArtStyle = '3D Disney Pixar Style' | 'Japanese Anime (Ghibli Style)' | 'Realistic Cinematic' | 'Claymation (Stop Motion)';
const ART_STYLES: ArtStyle[] = ['3D Disney Pixar Style', 'Japanese Anime (Ghibli Style)', 'Realistic Cinematic', 'Claymation (Stop Motion)'];

const VideoSceneCreator: React.FC = () => {
    const [ratio, setRatio] = useState<'9:16' | '16:9'>('9:16');
    const [artStyle, setArtStyle] = useState<ArtStyle>('Realistic Cinematic');
    const [language, setLanguage] = useState('Indonesia');
    const [mainReferenceImage, setMainReferenceImage] = useState<FilePreview | null>(null);
    const [visualDNA, setVisualDNA] = useState<string | null>(null);
    const [scenes, setScenes] = useState<Scene[]>([]);
    
    const [isLoadingScript, setIsLoadingScript] = useState(false);
    const [isScanning, setIsScanning] = useState(false);
    const [generatingImageForSceneId, setGeneratingImageForSceneId] = useState<number | null>(null);
    const [error, setError] = useState<string | null>(null);
    
    const [generatedImages, setGeneratedImages] = useState<Record<number, string>>({});
    const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

    const mainFileInputRef = useRef<HTMLInputElement | null>(null);

    const resetState = () => {
        setScenes([]);
        setGeneratedImages({});
        setError(null);
        setVisualDNA(null);
    };

    const handleMainFileChange = async (file: File | null) => {
        if (!file) return;
        resetState();
        setMainReferenceImage({ file, previewUrl: URL.createObjectURL(file) });
        
        setIsScanning(true);
        setError(null);
        try {
            const dna = await geminiService.generateCharacterDNA(file);
            setVisualDNA(dna);
        } catch (e: any) {
            setError(e.message || "Gagal memindai DNA visual dari gambar.");
        } finally {
            setIsScanning(false);
        }
    };
    
    const handleGenerateScript = async () => {
        if (!mainReferenceImage) {
            setError('Silakan upload foto referensi utama terlebih dahulu.');
            return;
        }
        setIsLoadingScript(true);
        setError(null);
        setScenes([]);
        setGeneratedImages({});
        try {
            const scriptText = await geminiService.generateStoryScriptFromImage(mainReferenceImage.file, language);
            const sceneTexts = scriptText.split(/SCENE \d+ - /).filter(s => s.trim() !== '');
            
            const newScenes: Scene[] = sceneTexts.map((text, index) => {
                const titleMatch = text.match(/(.*?)\n/);
                const title = titleMatch ? titleMatch[1].trim() : `Adegan ${index + 1}`;
                
                const scriptMatch = text.match(/\[SKRIP\]\s*([\s\S]*?)(?=\[PROMPT VISUAL\]|$)/);
                const visualPromptMatch = text.match(/\[PROMPT VISUAL\]\s*([\s\S]*)/);

                return {
                    id: Date.now() + index,
                    title: title,
                    script: scriptMatch ? scriptMatch[1].trim() : '',
                    visualPrompt: visualPromptMatch ? visualPromptMatch[1].trim() : '',
                };
            });
            setScenes(newScenes);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setIsLoadingScript(false);
        }
    };

    const handleGenerateImage = async (scene: Scene) => {
        if (!mainReferenceImage) {
            setError('Foto Referensi Utama tidak ditemukan.');
            return;
        }
        if (!scene.visualPrompt.trim()) {
            setError('PROMPT VISUAL tidak boleh kosong.');
            return;
        }
        setGeneratingImageForSceneId(scene.id);
        setError(null);
        
        const apiRatio = ratio === '16:9' ? '16:9' : '9:16';
        const fullPrompt = `
            ${artStyle}.
            ${visualDNA ? `**PENTING: Karakter harus cocok dengan DNA visual ini: ${visualDNA}.**` : ''}
            Latar belakang dan produk harus sama persis dengan gambar referensi. Jangan ubah itu.
            **Deskripsi Adegan:** ${scene.visualPrompt}.
            Gambar harus sangat konsisten dengan gambar referensi utama, hanya ubah aksi atau ekspresi seperti yang dijelaskan dalam deskripsi adegan.
        `;

        try {
            const imageUrl = await geminiService.generateProductImage(fullPrompt, mainReferenceImage.file, apiRatio);
            setGeneratedImages(prev => ({ ...prev, [scene.id]: imageUrl }));
        } catch(e: any) {
            setError(e.message || "Gagal membuat gambar adegan.");
        } finally {
            setGeneratingImageForSceneId(null);
        }
    };
    
    const handleSceneUpdate = (sceneId: number, field: keyof Scene, value: any) => {
        setScenes(prevScenes => prevScenes.map(scene => 
            scene.id === sceneId ? { ...scene, [field]: value } : scene
        ));
    };
    
    const handleDeleteScene = (sceneId: number) => {
        setScenes(prev => prev.filter(s => s.id !== sceneId));
        setGeneratedImages(prev => {
            const newImages = { ...prev };
            delete newImages[sceneId];
            return newImages;
        });
    };

    return (
        <>
            <FullscreenModal imageUrl={fullscreenImage} onClose={() => setFullscreenImage(null)} />
            <div className="container mx-auto max-w-5xl p-4 sm:p-6 lg:p-8">
                <header className="flex items-center gap-3 mb-6">
                    <FilmSlateIcon className="w-8 h-8 text-red-500" />
                    <h1 className="text-2xl sm:text-3xl font-bold text-white">Visual Storyboard Creator</h1>
                </header>
                
                <div className="bg-gray-900 p-6 rounded-xl shadow-md border border-gray-800 space-y-6">
                    
                    {/* Step 1: Main Upload & DNA Scan */}
                    <div className="p-4 bg-gray-800 rounded-lg">
                        <h3 className="font-bold text-lg text-white mb-3">1. Upload Referensi & Pindai DNA Visual</h3>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                            <div 
                                className="w-full sm:w-48 flex-shrink-0 p-2 border-2 border-dashed border-gray-700 rounded-lg cursor-pointer hover:border-purple-500 hover:bg-gray-700/50 transition-colors"
                                onClick={() => mainFileInputRef.current?.click()}
                            >
                                <input type="file" accept="image/*" ref={mainFileInputRef} onChange={e => handleMainFileChange(e.target.files ? e.target.files[0] : null)} className="hidden"/>
                                {mainReferenceImage ? (
                                    <img src={mainReferenceImage.previewUrl} alt="Referensi Utama" className="w-full h-auto object-contain rounded" />
                                ) : (
                                    <div className="flex flex-col items-center justify-center text-center h-40">
                                        <UploadIcon className="w-10 h-10 text-gray-500 mb-2"/>
                                        <p className="text-sm text-gray-400">Upload foto utama</p>
                                    </div>
                                )}
                            </div>
                            <div className="w-full">
                                <label className="flex items-center gap-2 text-sm font-semibold text-gray-300 mb-2">
                                    <LockIcon className="w-4 h-4 text-yellow-400"/> DNA Visual (Karakter & Produk)
                                </label>
                                <textarea readOnly value={isScanning ? 'Memindai...' : (visualDNA || 'DNA akan muncul di sini setelah upload...')} rows={6} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white"/>
                            </div>
                        </div>
                    </div>
                    
                    {/* Step 2: Generate Script */}
                    <div className="p-4 bg-gray-800 rounded-lg">
                        <h3 className="font-bold text-lg text-white mb-3">2. Generate Naskah Otomatis</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <select value={ratio} onChange={e => setRatio(e.target.value as '9:16' | '16:9')} className="custom-select w-full p-3 bg-gray-700 border border-gray-600 rounded-lg">
                                <option value="9:16">PORTRAIT (9:16)</option>
                                <option value="16:9">LANDSCAPE (16:9)</option>
                            </select>
                            <select value={artStyle} onChange={e => setArtStyle(e.target.value as ArtStyle)} className="custom-select w-full p-3 bg-gray-700 border border-gray-600 rounded-lg">
                                {ART_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                            <select value={language} onChange={e => setLanguage(e.target.value)} className="custom-select w-full p-3 bg-gray-700 border border-gray-600 rounded-lg">
                                <option>Indonesia</option>
                                <option>English</option>
                            </select>
                        </div>
                        <button 
                            onClick={handleGenerateScript} 
                            disabled={!mainReferenceImage || isLoadingScript || isScanning}
                            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-purple-600 text-white font-semibold rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed"
                        >
                            {isLoadingScript ? <Spinner className="!w-5 !h-5" /> : <WandIcon className="w-5 !h-5"/>}
                            {isLoadingScript ? "Menghasilkan Naskah..." : "Generate Naskah dari Foto"}
                        </button>
                    </div>

                    {/* Step 3: Scenes Area */}
                    {scenes.length > 0 && (
                        <div className="p-4 bg-gray-800 rounded-lg animate-fadeInDown">
                            <h3 className="font-bold text-lg text-white mb-3">3. Edit & Generate Gambar per Adegan</h3>
                            <div className="space-y-6">
                                {scenes.map((scene) => (
                                    <div key={scene.id} className="p-4 border border-gray-700 rounded-lg bg-gray-900/50 space-y-4">
                                        <div className="flex justify-between items-center">
                                            <input 
                                                type="text"
                                                value={`SCENE ${scene.id} - ${scene.title}`}
                                                onChange={e => handleSceneUpdate(scene.id, 'title', e.target.value.replace(`SCENE ${scene.id} - `, ''))}
                                                className="font-bold text-purple-400 bg-transparent border-0 p-0 focus:ring-0 w-full"
                                            />
                                            <button onClick={() => handleDeleteScene(scene.id)} className="p-1 text-gray-500 hover:text-red-400">
                                                <TrashIcon className="w-4 h-4"/>
                                            </button>
                                        </div>
                                        <div className="flex flex-col md:flex-row gap-4">
                                            <div className="w-full md:w-1/2 space-y-2">
                                                 <div>
                                                    <label className="text-xs text-gray-400 font-semibold">SKRIP (SULIH SUARA)</label>
                                                    <textarea
                                                        value={scene.script}
                                                        onChange={e => handleSceneUpdate(scene.id, 'script', e.target.value)}
                                                        className="w-full p-2 bg-gray-800 border border-gray-600 rounded-lg h-20 resize-y text-white text-sm"
                                                    />
                                                </div>
                                                 <div>
                                                    <label className="text-xs text-gray-400 font-semibold">PROMPT VISUAL</label>
                                                    <textarea
                                                        value={scene.visualPrompt}
                                                        onChange={e => handleSceneUpdate(scene.id, 'visualPrompt', e.target.value)}
                                                        className="w-full p-2 bg-gray-800 border border-gray-600 rounded-lg h-24 resize-y text-white text-sm"
                                                    />
                                                </div>
                                            </div>
                                            <div className="w-full md:w-1/2 flex flex-col gap-2">
                                                <div className={`aspect-video w-full bg-black rounded-lg flex items-center justify-center relative group`}>
                                                    {generatingImageForSceneId === scene.id && <Spinner />}
                                                    {generatingImageForSceneId !== scene.id && generatedImages[scene.id] && (
                                                        <>
                                                            <img src={generatedImages[scene.id]} alt={`Adegan ${scene.title}`} className="w-full h-full object-cover rounded-lg"/>
                                                            <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                                <button onClick={() => setFullscreenImage(generatedImages[scene.id])} className="p-1.5 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Tampilan Penuh"><ExpandIcon className="w-4 h-4" /></button>
                                                                <a href={generatedImages[scene.id]} download={`scene-${scene.id}.png`} className="p-1.5 bg-black/50 hover:bg-black/80 rounded-full text-white" title="Unduh"><DownloadIcon className="w-4 h-4" /></a>
                                                            </div>
                                                        </>
                                                    )}
                                                     {generatingImageForSceneId !== scene.id && !generatedImages[scene.id] && (
                                                        <GalleryIcon className="w-10 h-10 text-gray-600"/>
                                                    )}
                                                </div>
                                                <button 
                                                    onClick={() => handleGenerateImage(scene)} 
                                                    disabled={isLoadingScript || generatingImageForSceneId !== null}
                                                    className="w-full flex items-center justify-center gap-2 p-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
                                                >
                                                    {generatingImageForSceneId === scene.id ? <Spinner className="!w-4 !h-4" /> : <ImageIcon className="w-4 h-4" />}
                                                    {generatingImageForSceneId === scene.id ? 'Membuat...' : `Generate Gambar Adegan`}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    {error && <p className="text-center text-red-400 bg-red-900/30 p-3 rounded-md">{error}</p>}
                </div>
            </div>
        </>
    );
};

export default VideoSceneCreator;