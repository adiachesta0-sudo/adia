
import React from 'react';
import { FEATURES, FeatureID } from '../constants';
import type { Feature } from '../types';

// Icon for external links, defined locally to avoid creating a new file.
const ExternalLinkIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-4.5 0V6H18m-4.5 0L18 6" />
    </svg>
);

interface SidebarProps {
  activeFeature: FeatureID;
  setActiveFeature: (feature: FeatureID) => void;
  isSidebarOpen: boolean;
  setSidebarOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeFeature, setActiveFeature, isSidebarOpen, setSidebarOpen }) => {
  
  const handleFeatureClick = (feature: Feature) => {
    if (feature.externalLink) {
      window.open(feature.externalLink, '_blank', 'noopener,noreferrer');
    } else {
      setActiveFeature(feature.id);
    }
    setSidebarOpen(false); // Close sidebar on selection
  };

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/50 z-30 md:hidden transition-opacity ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setSidebarOpen(false)}
      ></div>
      <aside 
        className={`fixed top-0 left-0 h-full w-64 bg-gray-900 text-gray-200 flex flex-col z-40 transform transition-transform md:relative md:translate-x-0 border-r border-gray-800 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="p-4 border-b border-gray-800">
          <h2 className="text-2xl font-bold text-white">SENA GENERATOR</h2>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {FEATURES.map((feature) => {
            const Icon = feature.icon;
            const isActive = feature.id === activeFeature;
            return (
              <button
                key={feature.id}
                onClick={() => handleFeatureClick(feature)}
                className={`w-full flex items-center p-3 rounded-md text-left text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-purple-600 text-white'
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 mr-3`} />
                <span className="flex-grow">{feature.name}</span>
                {feature.externalLink && <ExternalLinkIcon className="text-gray-500" />}
              </button>
            );
          })}
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;