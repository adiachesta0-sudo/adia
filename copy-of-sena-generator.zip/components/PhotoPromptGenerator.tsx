
import React, { useState } from 'react';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';
import { WandIcon } from './icons/WandIcon';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';
import { FEATURES, FeatureID } from '../constants';

const ART_STYLES = ['Fotorealistis', 'Lukisan Digital', 'Gaya Anime', '3D Render', 'Seni Konsep', 'Cat Air'];
const DETAIL_LEVELS = ['Sederhana', 'Cukup Detail', 'Sangat Detail (8k)'];
const CAMERA_ANGLES = ['Eye Level', 'High Angle', 'Low Angle', 'Dutch Angle', 'Close Up'];

const PhotoPromptGenerator: React.FC = () => {
    const [idea, setIdea] = useState('Seorang ksatria naga di puncak gunung');
    const [artStyle, setArtStyle] = useState('Fotorealistis');
    const [detailLevel, setDetailLevel] = useState('Sangat Detail (8k)');
    const [cameraAngle, setCameraAngle] = useState('Eye Level');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedPrompt, setGeneratedPrompt] = useState<string | null>(null);
    const [isCopied, setIsCopied] = useState(false);
    
    const featureConfig = FEATURES.find(f => f.id === FeatureID.PhotoPromptGenerator);

    const handleGenerate = async () => {
        if (!idea.trim() || !featureConfig) {
            setError('Ide tidak boleh kosong.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setGeneratedPrompt(null);
        setIsCopied(false);

        const metaPrompt = `
        Tugas Anda adalah sebagai ahli pembuat prompt untuk AI generator gambar.
        Buatlah sebuah prompt yang sangat deskriptif dalam Bahasa Indonesia berdasarkan detail berikut:

        - Ide Utama: "${idea}"
        - Gaya Seni: "${artStyle}"
        - Tingkat Detail: "${detailLevel}"
        - Sudut Kamera: "${cameraAngle}"

        Instruksi Penting:
        1. Prompt yang dihasilkan harus menjadi satu paragraf tunggal yang kaya akan detail visual.
        2. Jelaskan subjek, latar belakang, pencahayaan (misalnya: 'pencahayaan sinematik', 'cahaya lembut'), palet warna, dan komposisi.
        3. Gabungkan semua elemen ini menjadi sebuah narasi visual yang kohesif. Prompt harus melukiskan gambaran yang lengkap dan membangkitkan imajinasi.
        4. Prompt HARUS dalam Bahasa Indonesia.
        `;

        try {
            const result = await geminiService.generateText(metaPrompt, undefined, featureConfig.model);
            setGeneratedPrompt(result.trim());
        } catch (e: any) {
            setError(e.message || 'Terjadi kesalahan tak terduga.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopy = () => {
        if (generatedPrompt) {
            navigator.clipboard.writeText(generatedPrompt);
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        }
    };

    const SelectInput = ({ label, value, onChange, options }: { label: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, options: string[] }) => (
        <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">{label}</label>
            <select value={value} onChange={onChange} className="custom-select w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500">
                {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
        </div>
    );

    return (
        <div className="container mx-auto max-w-4xl p-4 sm:p-6 lg:p-8">
            <div className="mb-8">
                <h1 className="text-3xl sm:text-4xl font-bold mb-2 text-white flex items-center gap-3">
                    <WandIcon className="w-8 h-8 text-purple-400"/>
                    Prompt Foto AI
                </h1>
                <p className="text-gray-400">{featureConfig?.description}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Control Panel */}
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg space-y-6">
                    <div>
                        <label htmlFor="idea" className="block text-base font-semibold text-gray-300 mb-2">1. Masukkan Ide Dasar Anda</label>
                        <textarea
                            id="idea"
                            value={idea}
                            onChange={(e) => setIdea(e.target.value)}
                            placeholder="Contoh: Seorang astronot di hutan fantasi"
                            className="w-full h-28 p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                    </div>

                    <div className="space-y-4">
                        <h2 className="text-base font-semibold text-gray-300">2. Pilih Opsi Tambahan</h2>
                        <SelectInput label="Gaya Seni" value={artStyle} onChange={(e) => setArtStyle(e.target.value)} options={ART_STYLES} />
                        <SelectInput label="Tingkat Detail" value={detailLevel} onChange={(e) => setDetailLevel(e.target.value)} options={DETAIL_LEVELS} />
                        <SelectInput label="Sudut Kamera" value={cameraAngle} onChange={(e) => setCameraAngle(e.target.value)} options={CAMERA_ANGLES} />
                    </div>
                     <button
                        onClick={handleGenerate}
                        disabled={isLoading}
                        className="w-full flex items-center justify-center gap-2 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed text-lg"
                    >
                        {isLoading ? <Spinner className="!w-6 !h-6" /> : <WandIcon className="w-6 h-6"/>}
                        Buat Prompt
                    </button>
                </div>

                {/* Result Display */}
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col">
                    <h2 className="text-lg font-semibold text-white mb-4">Hasil Prompt</h2>
                    <div className="flex-grow bg-black rounded-md p-4 min-h-[300px] flex items-center justify-center">
                        {isLoading && <Spinner />}
                        {error && <p className="text-red-400 text-center">{error}</p>}
                        {!isLoading && !error && generatedPrompt && (
                             <p className="text-gray-300 whitespace-pre-wrap text-sm animate-fadeInDown">{generatedPrompt}</p>
                        )}
                         {!isLoading && !error && !generatedPrompt && (
                             <p className="text-gray-500 text-center">Prompt yang dihasilkan akan muncul di sini.</p>
                        )}
                    </div>
                    {generatedPrompt && !isLoading && (
                        <button
                            onClick={handleCopy}
                            className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 bg-gray-600 hover:bg-gray-700 text-white font-semibold rounded-lg transition-colors"
                        >
                            {isCopied ? <CheckIcon className="w-5 h-5 text-green-400"/> : <ClipboardIcon className="w-5 h-5"/>}
                            {isCopied ? 'Tersalin!' : 'Salin Prompt'}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PhotoPromptGenerator;
