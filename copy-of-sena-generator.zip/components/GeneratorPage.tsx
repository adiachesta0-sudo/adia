
import React, { useState, useEffect } from 'react';
import type { Feature } from '../types';
import * as geminiService from '../services/geminiService';
import { playAudio } from '../utils/audio';
import Spinner from './Spinner';

interface GeneratorPageProps {
  feature: Feature;
}

const GeneratorPage: React.FC<GeneratorPageProps> = ({ feature }) => {
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});

  useEffect(() => {
    // Reset state when feature changes
    setPrompt('');
    setResult(null);
    setError(null);
    setIsLoading(false);

    const initialOptions: Record<string, string> = {};
    if (feature.options) {
      feature.options.forEach(option => {
        initialOptions[option.id] = option.defaultValue;
      });
    }
    setSelectedOptions(initialOptions);
  }, [feature]);

  const handleOptionChange = (optionId: string, value: string) => {
    setSelectedOptions(prev => ({ ...prev, [optionId]: value }));
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      let response;
      
      let optionsText = '';
      if (feature.options) {
          optionsText = feature.options.map(opt => `${opt.label}: ${selectedOptions[opt.id]}`).join(', ');
      }
      const fullPrompt = `${feature.promptPrefix || ''}${optionsText ? ` (${optionsText}). ` : ''}${prompt}`;


      switch (feature.outputType) {
        case 'text':
          response = await geminiService.generateText(fullPrompt, feature.systemInstruction, feature.model);
          setResult(response);
          break;
        case 'image':
          response = await geminiService.generateImage(fullPrompt, feature.model);
          setResult(response);
          break;
        case 'audio':
          const audioData = await geminiService.generateTextToSpeech(fullPrompt, 'Kore');
          await playAudio(audioData); 
          setResult('Audio generated and played successfully.');
          break;
      }
    } catch (e: any) {
      console.error(e);
      setError(e.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderOptions = () => {
    if (!feature.options) return null;

    return (
        <div className="animate-fadeInDown">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {feature.options.map(option => (
                    <div key={option.id}>
                        <label htmlFor={option.id} className="block text-sm font-medium text-gray-300 mb-2">{option.label}</label>
                        <select
                            id={option.id}
                            value={selectedOptions[option.id] || ''}
                            onChange={(e) => handleOptionChange(option.id, e.target.value)}
                            className="custom-select w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 focus:outline-none transition-colors duration-200"
                        >
                            {option.values.map(val => (
                                <option key={val} value={val}>{val}</option>
                            ))}
                        </select>
                    </div>
                ))}
            </div>
        </div>
    );
  };

  const renderResult = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center p-8 bg-gray-800 border border-dashed border-gray-700 rounded-lg min-h-[200px]">
          <Spinner />
          <p className="mt-4 text-gray-500">Generating...</p>
        </div>
      );
    }
    if (error) {
      return (
        <div className="p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-lg">
          <p className="font-bold">Error:</p>
          <p>{error}</p>
        </div>
      );
    }
    if (!result) {
      return (
        <div className="flex items-center justify-center p-8 bg-gray-800 border border-dashed border-gray-700 rounded-lg min-h-[200px]">
          <p className="text-gray-500">Your generated content will appear here.</p>
        </div>
      );
    }

    switch (feature.outputType) {
      case 'image':
        return <img src={result} alt="Generated content" className="rounded-lg shadow-md max-w-full mx-auto" />;
      case 'audio':
        return <p className="text-green-400 p-4 bg-green-900/50 rounded-lg">{result}</p>;
      case 'text':
        return <div className="p-4 bg-gray-800 rounded-lg whitespace-pre-wrap">{result}</div>;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold mb-2 text-white">{feature.name}</h1>
        <p className="text-gray-400">{feature.description}</p>
      </div>

      <div className="p-6 bg-gray-800 rounded-lg shadow-lg space-y-6">
        {renderOptions()}
        <div className="flex flex-col md:flex-row gap-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={feature.promptPlaceholder}
            className="flex-grow p-4 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 focus:outline-none resize-none min-h-[100px] md:min-h-[60px] transition-colors duration-200"
            rows={3}
          />
          <button
            onClick={handleGenerate}
            disabled={isLoading}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
          >
            {isLoading && <Spinner className="!w-5 !h-5 mr-2" />}
            Generate
          </button>
        </div>
        
        <div className="mt-8">
            {renderResult()}
        </div>
      </div>
    </div>
  );
};

export default GeneratorPage;