
import React from 'react';

export const LandscapeIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 12.75H3m18 0a8.962 8.962 0 0 1-2.286 6.132M3 12.75a8.962 8.962 0 0 0 2.286 6.132m13.428-6.132a8.962 8.962 0 0 0-2.286-6.132M3 12.75a8.962 8.962 0 0 1 2.286-6.132m13.428 6.132L21 12.75M3 12.75l2.286 6.132" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 17.25h16.5" />
  </svg>
);