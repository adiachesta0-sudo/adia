
import React from 'react';

export const AnimationIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6 6 6 0 00-6-6M12 18.75a6 6 0 01-6-6 6 6 0 016-6m1.5-3.75l-1.5 1.5-1.5-1.5m1.5 15l-1.5-1.5-1.5 1.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 5.25l-1.5 1.5 1.5 1.5m12 0l1.5-1.5-1.5-1.5"/>
    </svg>
);