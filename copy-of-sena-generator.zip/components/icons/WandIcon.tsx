
import React from 'react';

export const WandIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 0 0-2.24 2.24l.14.735a.6.6 0 0 0 .93.41l2.5-2.5a3 3 0 0 0-2.33-5.885l-.16.03Zm-5.3 5.3a.6.6 0 0 1 .41-.93l.735-.14a3 3 0 0 1 2.24 2.24l2.5-2.5a3 3 0 0 1 5.885 2.33l-.03.16a.6.6 0 0 1-.93.41l-5.3-5.3Zm12.02-12.02a3 3 0 0 0-2.24-2.24l-.14-.735a.6.6 0 0 0-.93-.41l-2.5 2.5a3 3 0 0 0 5.885 2.33l.16-.03a.6.6 0 0 0 .41-.93l-.735.14Zm-5.3-5.3a.6.6 0 0 1-.41.93l-.735.14a3 3 0 0 1-2.24-2.24l-2.5 2.5a3 3 0 0 1-5.885-2.33l.03-.16a.6.6 0 0 1 .93-.41l5.3 5.3Z" />
    </svg>
);