
import React from 'react';

export const FilmSlateIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-2.25-1.313M21 7.5v11.25m0-11.25l-2.25 1.313M3 7.5l2.25-1.313M3 7.5v11.25m0-11.25l2.25 1.313M12 5.25v2.25m0 0l-2.25 1.313M12 7.5l2.25 1.313M12 7.5v11.25m0 0l-2.25-1.313m2.25 1.313l2.25-1.313" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 4.5h18M3 4.5v13.5h18V4.5M3 4.5L2.25 3m19.5 1.5L21.75 3" />
    </svg>
);