
import React from 'react';

export const PortraitIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3.75h10.5M6.75 20.25h10.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3v18M12.75 3a8.962 8.962 0 0 1 6.132 2.286M12.75 3a8.962 8.962 0 0 0-6.132 2.286m12.264 0A8.962 8.962 0 0 1 21 12.75m-2.286-6.714A8.962 8.962 0 0 0 12.75 21m6.714-2.286A8.962 8.962 0 0 1 12.75 3M3 6.75A8.962 8.962 0 0 1 5.286 3m-2.286 3.75A8.962 8.962 0 0 0 21 12.75m-18 0a8.962 8.962 0 0 1 2.286-6.132" />
    </svg>
);