
import React from 'react';

export const LayersIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.115 5.19A.75.75 0 0 1 6 6v12a.75.75 0 0 1-1.22.58L3.14 16.5a.75.75 0 0 1 0-1.16l1.64-2.186a.75.75 0 0 1 1.335.58ZM12.75 5.19A.75.75 0 0 1 12 6v12a.75.75 0 0 1-1.22.58L9.14 16.5a.75.75 0 0 1 0-1.16l1.64-2.186a.75.75 0 0 1 1.335.58ZM19.385 5.19A.75.75 0 0 1 18.75 6v12a.75.75 0 0 1-1.22.58l-1.64-2.186a.75.75 0 0 1 0-1.16l1.64-2.186a.75.75 0 0 1 1.335.58Z" />
    </svg>
);