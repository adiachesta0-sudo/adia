
import React from 'react';

export const FoodIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c.51 0 .962-.343 1.087-.835l.383-1.437M7.5 14.25V5.106M7.5 14.25a2.25 2.25 0 01-2.25 2.25M15 11.25a3 3 0 01-3 3M15 11.25a3 3 0 01-3-3M15 11.25v3.75M15 11.25c0-1.242-1.008-2.25-2.25-2.25S10.5 10.008 10.5 11.25" />
    </svg>
);