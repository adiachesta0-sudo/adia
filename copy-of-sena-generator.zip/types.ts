// FIX: Import React to use React.ComponentType
import React from 'react';
import { FeatureID } from './constants';

export type OutputType = 'text' | 'image' | 'audio' | 'video';

export type VoiceGender = 'Pria' | 'Wanita' | 'Netral';
export type VoiceStyle = 'Narator' | 'Pendidik/Pengajar' | 'Meyakinkan/Profesional' | 'Pelatih/Ceria' | 'Motivator' | 'Ekspresif secara Emosional';


export interface FeatureOption {
  id: string;
  label: string;
  type: 'select';
  values: string[];
  defaultValue: string;
}

export interface Voice {
  name: string;
  apiName: string;
  description: string;
  gender: VoiceGender;
  styles: VoiceStyle[];
}


export interface Feature {
  id: FeatureID;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  outputType: OutputType;
  promptPlaceholder: string;
  systemInstruction?: string;
  model: string;
  promptPrefix?: string;
  options?: FeatureOption[];
  externalLink?: string;
}

// FIX: Add missing CustomLink type for ManageLinks component
export interface CustomLink {
  id: number;
  name: string;
  url: string;
}

export interface GeneratedContentPack {
  imageUrl: string;
  prompt: string;
  hook: string;
  problem: string;
  solution: string;
  cta: string;
}

export interface GeneratedTheme {
    theme: string;
    images: string[];
}